"""
Generates crisp, realistic synthetic electronic circuit images and bundled demonstration data.
Enables immediate testing without needing to find or photograph hardware.
"""

import os
from typing import Dict, Tuple
from PIL import Image, ImageDraw, ImageFont
from circuit_analyzer.models import (
    CircuitAnalysisResult,
    CircuitComponent,
    BoundingBox,
    BOMItem,
    InspectionFinding,
)
from circuit_analyzer.visualizer import get_default_font


def create_sample_1_ne555_pcb() -> Tuple[Image.Image, CircuitAnalysisResult]:
    """Generates an image and analysis result for an NE555 Timer Astable Flasher Circuit."""
    width, height = 1000, 750
    # Dark green PCB substrate
    img = Image.new("RGB", (width, height), (18, 53, 36))
    draw = ImageDraw.Draw(img)
    font_bold = get_default_font(18)
    font_sm = get_default_font(12)
    font_title = get_default_font(24)

    # PCB border and mounting holes
    draw.rectangle([(20, 20), (980, 730)], outline=(34, 94, 64), width=4)
    # Mounting holes at 4 corners
    for hx, hy in [(50, 50), (950, 50), (50, 700), (950, 700)]:
        draw.ellipse([(hx - 15, hy - 15), (hx + 15, hy + 15)], fill=(195, 175, 110), outline=(230, 210, 140), width=2)
        draw.ellipse([(hx - 9, hy - 9), (hx + 9, hy + 9)], fill=(12, 35, 24))

    # Copper ground plane hatch traces
    for y in range(80, 680, 45):
        draw.line([(60, y), (940, y)], fill=(22, 65, 44), width=2)

    # Silkscreen title
    draw.text((360, 40), "NE555 ASTABLE OSCILLATOR REV 1.2", fill=(240, 240, 240), font=font_title)
    draw.text((430, 70), "DESIGN: PRACTICAL GENAI LAB", fill=(190, 210, 195), font=font_sm)

    # 1. Main IC: NE555 (U1) - DIP-8 package in center
    # Bounding box in 0-1000 coords: [ymin=280, xmin=380, ymax=520, xmax=620]
    u1_box = (380, 210, 620, 390)
    # Silkscreen outline & notch
    draw.rectangle([(370, 200), (630, 400)], outline=(240, 240, 240), width=2)
    draw.arc([(485, 190), (515, 210)], start=0, end=180, fill=(240, 240, 240), width=2)
    # Chip body (Matte black epoxy)
    draw.rectangle(u1_box, fill=(30, 32, 35), outline=(60, 64, 70), width=2)
    # IC Pins (4 on top, 4 on bottom)
    for px in [410, 470, 530, 590]:
        # Top pin
        draw.rectangle([(px - 10, 180), (px + 10, 210)], fill=(180, 185, 195), outline=(130, 135, 145))
        # Bottom pin
        draw.rectangle([(px - 10, 390), (px + 10, 420)], fill=(180, 185, 195), outline=(130, 135, 145))
    # IC Text
    draw.text((420, 275), "TI  NE555P", fill=(210, 210, 215), font=font_bold)
    draw.text((435, 305), "24M6A2X", fill=(140, 145, 150), font=font_sm)
    draw.ellipse([(395, 225), (405, 235)], fill=(150, 150, 150)) # Pin 1 index dot
    draw.text((385, 175), "U1", fill=(240, 240, 240), font=font_bold)

    # 2. Timing Resistor R1 (1kΩ)
    # Bounding box: [ymin=160, xmin=140, ymax=240, xmax=320]
    draw.line([(110, 150), (350, 150)], fill=(190, 195, 200), width=4) # Lead wire
    draw.rectangle([(160, 135), (300, 165)], fill=(222, 184, 135), outline=(140, 110, 75), width=2) # Beige body
    # Color bands: Brown (1), Black (0), Red (x100), Gold (5%) -> 1kΩ
    draw.rectangle([(180, 135), (192, 165)], fill=(139, 69, 19))  # Brown
    draw.rectangle([(205, 135), (217, 165)], fill=(20, 20, 20))    # Black
    draw.rectangle([(230, 135), (242, 165)], fill=(220, 30, 30))   # Red
    draw.rectangle([(265, 135), (277, 165)], fill=(218, 165, 32))  # Gold
    draw.text((215, 105), "R1 (1kΩ)", fill=(240, 240, 240), font=font_bold)

    # 3. Timing Resistor R2 (10kΩ)
    # Bounding box: [ymin=280, xmin=140, ymax=360, xmax=320]
    draw.line([(110, 270), (350, 270)], fill=(190, 195, 200), width=4)
    draw.rectangle([(160, 255), (300, 285)], fill=(222, 184, 135), outline=(140, 110, 75), width=2)
    # Brown (1), Black (0), Orange (x1k), Gold (5%) -> 10kΩ
    draw.rectangle([(180, 255), (192, 285)], fill=(139, 69, 19))  # Brown
    draw.rectangle([(205, 255), (217, 285)], fill=(20, 20, 20))    # Black
    draw.rectangle([(230, 255), (242, 285)], fill=(255, 140, 0))   # Orange
    draw.rectangle([(265, 255), (277, 285)], fill=(218, 165, 32))  # Gold
    draw.text((210, 225), "R2 (10kΩ)", fill=(240, 240, 240), font=font_bold)

    # 4. Output LED Resistor R3 (330Ω)
    draw.line([(680, 220), (900, 220)], fill=(190, 195, 200), width=4)
    draw.rectangle([(720, 205), (860, 235)], fill=(222, 184, 135), outline=(140, 110, 75), width=2)
    # Orange (3), Orange (3), Brown (x10), Gold -> 330Ω
    draw.rectangle([(740, 205), (752, 235)], fill=(255, 140, 0))   # Orange
    draw.rectangle([(765, 205), (777, 235)], fill=(255, 140, 0))   # Orange
    draw.rectangle([(790, 205), (802, 235)], fill=(139, 69, 19))   # Brown
    draw.rectangle([(825, 205), (837, 235)], fill=(218, 165, 32))  # Gold
    draw.text((770, 175), "R3 (330Ω)", fill=(240, 240, 240), font=font_bold)

    # 5. Timing Electrolytic Capacitor C1 (10µF 25V)
    # Big cylindrical radial can
    draw.rectangle([(150, 410), (310, 570)], outline=(240, 240, 240), width=2) # Silkscreen circle footprint
    draw.ellipse([(160, 420), (300, 560)], fill=(30, 45, 90), outline=(15, 25, 55), width=3) # Blue sleeve
    # Polarity white stripe on negative side
    draw.pieslice([(160, 420), (300, 560)], start=135, end=225, fill=(220, 225, 235))
    draw.text((165, 480), "---", fill=(30, 45, 90), font=font_bold)
    draw.text((215, 470), "10µF", fill=(255, 255, 255), font=font_bold)
    draw.text((215, 495), "25V", fill=(230, 230, 240), font=font_sm)
    draw.text((210, 385), "C1 (10µF)", fill=(240, 240, 240), font=font_bold)

    # 6. Ceramic Decoupling Capacitor C2 (0.01µF / 104)
    draw.line([(450, 490), (550, 490)], fill=(190, 195, 200), width=3)
    draw.ellipse([(470, 465), (530, 515)], fill=(210, 120, 40), outline=(160, 80, 20), width=2) # Orange ceramic disc
    draw.text((485, 482), "103", fill=(30, 30, 30), font=font_sm)
    draw.text((480, 525), "C2 (10nF)", fill=(240, 240, 240), font=font_bold)

    # 7. Red Indicator LED D1
    draw.rectangle([(710, 340), (870, 500)], outline=(240, 240, 240), width=2)
    # 5mm Dome LED
    draw.ellipse([(735, 365), (845, 475)], fill=(220, 20, 30), outline=(160, 10, 20), width=3)
    # Inner lens glow reflection
    draw.ellipse([(755, 385), (795, 425)], fill=(255, 120, 130))
    draw.text((770, 310), "D1 (LED)", fill=(240, 240, 240), font=font_bold)
    draw.text((765, 510), "PULSE OUT", fill=(190, 210, 195), font=font_sm)

    # 8. Power Terminal Block J1 (2-pin screw connector)
    draw.rectangle([(80, 570), (220, 690)], fill=(40, 130, 60), outline=(25, 80, 40), width=3)
    # Screws
    for sy in [600, 660]:
        draw.ellipse([(120, sy - 15), (150, sy + 15)], fill=(190, 195, 200), outline=(120, 125, 130), width=2)
        draw.line([(125, sy), (145, sy)], fill=(50, 50, 50), width=3)
    draw.text((160, 590), "+VCC (9V)", fill=(240, 240, 240), font=font_bold)
    draw.text((160, 650), "GND", fill=(240, 240, 240), font=font_bold)
    draw.text((120, 545), "J1 (POWER IN)", fill=(240, 240, 240), font=font_bold)

    # 9. Output Header Pin J2
    draw.rectangle([(750, 570), (830, 670)], fill=(30, 32, 35), outline=(70, 75, 80), width=2)
    draw.ellipse([(780, 595), (800, 615)], fill=(218, 165, 32), outline=(160, 120, 20), width=2)
    draw.ellipse([(780, 635), (800, 655)], fill=(218, 165, 32), outline=(160, 120, 20), width=2)
    draw.text((750, 680), "J2 (OUT/GND)", fill=(240, 240, 240), font=font_bold)

    # Build corresponding structured analysis result
    components = [
        CircuitComponent(
            id="U1",
            name="Texas Instruments NE555P Precision Timer IC",
            category="Integrated Circuit",
            designator="U1",
            value_or_rating="NE555P",
            package="DIP-8 (Dual In-line Package)",
            markings="TI NE555P 24M6A2X",
            location_description="Center of PCB",
            bounding_box=BoundingBox(
                ymin=int((200 / height) * 1000),
                xmin=int((370 / width) * 1000),
                ymax=int((420 / height) * 1000),
                xmax=int((630 / width) * 1000)
            ),
            estimated_function="Core astable multivibrator clock generator producing square wave pulses",
            confidence="High"
        ),
        CircuitComponent(
            id="R1",
            name="Through-Hole Carbon Film Resistor",
            category="Resistor",
            designator="R1",
            value_or_rating="1kΩ (±5%)",
            package="Axial Through-Hole (0.25W)",
            markings="Brown-Black-Red-Gold",
            location_description="Upper left, connected between VCC and Discharge (Pin 7)",
            bounding_box=BoundingBox(
                ymin=int((135 / height) * 1000),
                xmin=int((140 / width) * 1000),
                ymax=int((185 / height) * 1000),
                xmax=int((320 / width) * 1000)
            ),
            estimated_function="First timing resistor controlling charging phase of capacitor C1",
            confidence="High"
        ),
        CircuitComponent(
            id="R2",
            name="Through-Hole Carbon Film Resistor",
            category="Resistor",
            designator="R2",
            value_or_rating="10kΩ (±5%)",
            package="Axial Through-Hole (0.25W)",
            markings="Brown-Black-Orange-Gold",
            location_description="Mid-left, between Pin 7 (Discharge) and Pin 6/2 (Threshold/Trigger)",
            bounding_box=BoundingBox(
                ymin=int((250 / height) * 1000),
                xmin=int((140 / width) * 1000),
                ymax=int((300 / height) * 1000),
                xmax=int((320 / width) * 1000)
            ),
            estimated_function="Second timing resistor determining duty cycle and discharge rate",
            confidence="High"
        ),
        CircuitComponent(
            id="R3",
            name="Current Limiting Resistor",
            category="Resistor",
            designator="R3",
            value_or_rating="330Ω (±5%)",
            package="Axial Through-Hole (0.25W)",
            markings="Orange-Orange-Brown-Gold",
            location_description="Upper right, connected in series with LED D1",
            bounding_box=BoundingBox(
                ymin=int((195 / height) * 1000),
                xmin=int((700 / width) * 1000),
                ymax=int((250 / height) * 1000),
                xmax=int((880 / width) * 1000)
            ),
            estimated_function="Limits forward current through indicator LED D1 to prevent burnout",
            confidence="High"
        ),
        CircuitComponent(
            id="C1",
            name="Aluminum Electrolytic Capacitor",
            category="Capacitor",
            designator="C1",
            value_or_rating="10µF 25V",
            package="Radial Can (6.3mm dia)",
            markings="10µF 25V with negative polarity stripe",
            location_description="Lower left, timing capacitor to ground",
            bounding_box=BoundingBox(
                ymin=int((405 / height) * 1000),
                xmin=int((150 / width) * 1000),
                ymax=int((575 / height) * 1000),
                xmax=int((315 / width) * 1000)
            ),
            estimated_function="Determines pulse oscillation frequency via charge/discharge curve",
            confidence="High"
        ),
        CircuitComponent(
            id="C2",
            name="Ceramic Disc Capacitor",
            category="Capacitor",
            designator="C2",
            value_or_rating="10nF (0.01µF / 103)",
            package="Radial Disc Through-Hole",
            markings="103",
            location_description="Directly below U1, connected to Control Voltage (Pin 5)",
            bounding_box=BoundingBox(
                ymin=int((460 / height) * 1000),
                xmin=int((450 / width) * 1000),
                ymax=int((525 / height) * 1000),
                xmax=int((550 / width) * 1000)
            ),
            estimated_function="Bypass capacitor decoupling Pin 5 to ground, suppressing electrical noise",
            confidence="High"
        ),
        CircuitComponent(
            id="D1",
            name="5mm Red Indicator LED",
            category="Diode / LED",
            designator="D1",
            value_or_rating="2.0V 20mA Red",
            package="T-1 3/4 (5mm) Through-Hole",
            markings="Red diffused dome package with cathode flat",
            location_description="Right middle area, connected to output Pin 3",
            bounding_box=BoundingBox(
                ymin=int((330 / height) * 1000),
                xmin=int((710 / width) * 1000),
                ymax=int((500 / height) * 1000),
                xmax=int((870 / width) * 1000)
            ),
            estimated_function="Provides visual optical feedback of oscillating square-wave output",
            confidence="High"
        ),
        CircuitComponent(
            id="J1",
            name="2-Position Screw Terminal Block",
            category="Connector / Terminal",
            designator="J1",
            value_or_rating="5.0mm Pitch, 300V 10A",
            package="Through-Hole Terminal Block",
            markings="+VCC (9V) / GND",
            location_description="Bottom left corner, main DC power input",
            bounding_box=BoundingBox(
                ymin=int((565 / height) * 1000),
                xmin=int((75 / width) * 1000),
                ymax=int((695 / height) * 1000),
                xmax=int((225 / width) * 1000)
            ),
            estimated_function="External DC power supply connector (supports 5V - 12V battery or adapter)",
            confidence="High"
        ),
        CircuitComponent(
            id="J2",
            name="2-Pin Male Header Connector",
            category="Connector / Terminal",
            designator="J2",
            value_or_rating="2.54mm (0.1\") Pin Header",
            package="Through-Hole 1x2 Header",
            markings="OUT / GND",
            location_description="Bottom right, auxiliary output tap",
            bounding_box=BoundingBox(
                ymin=int((565 / height) * 1000),
                xmin=int((745 / width) * 1000),
                ymax=int((675 / height) * 1000),
                xmax=int((835 / width) * 1000)
            ),
            estimated_function="Provides access to raw output pulse signal for external oscilloscope or load",
            confidence="High"
        ),
    ]

    bom = [
        BOMItem(designator="U1", component_type="Integrated Circuit", description="NE555P Precision Timer IC", package="DIP-8", quantity=1, notes="Texas Instruments"),
        BOMItem(designator="R1", component_type="Resistor", description="1kΩ ±5% 0.25W Carbon Film", package="Axial Through-Hole", quantity=1, notes="Timing R_A"),
        BOMItem(designator="R2", component_type="Resistor", description="10kΩ ±5% 0.25W Carbon Film", package="Axial Through-Hole", quantity=1, notes="Timing R_B"),
        BOMItem(designator="R3", component_type="Resistor", description="330Ω ±5% 0.25W Carbon Film", package="Axial Through-Hole", quantity=1, notes="LED Current Limiting"),
        BOMItem(designator="C1", component_type="Capacitor", description="10µF 25V Electrolytic Capacitor", package="Radial 6.3mm", quantity=1, notes="Main Timing Cap"),
        BOMItem(designator="C2", component_type="Capacitor", description="10nF (0.01µF) Ceramic Capacitor", package="Radial Disc", quantity=1, notes="Control Voltage Decoupling"),
        BOMItem(designator="D1", component_type="Diode / LED", description="5mm Red Diffused LED", package="T-1 3/4 Through-Hole", quantity=1, notes="Output Status"),
        BOMItem(designator="J1", component_type="Connector", description="2-Pin 5.0mm Pitch Screw Terminal", package="Through-Hole", quantity=1, notes="DC Power Input"),
        BOMItem(designator="J2", component_type="Connector", description="2-Pin 2.54mm Male Header", package="1x2 Pin Header", quantity=1, notes="Pulse Output Tap"),
    ]

    inspection = [
        InspectionFinding(aspect="Polarity & Orientation", status="Good", observation="C1 electrolytic polarity negative stripe correctly marked; U1 pin 1 index notch aligned towards top."),
        InspectionFinding(aspect="Silkscreen Integrity", status="Good", observation="Clear reference designators (U1, R1-R3, C1-C2, D1, J1) and component values legibly labeled."),
        InspectionFinding(aspect="Solder Pad Spacing", status="Good", observation="Standard 2.54mm DIP and through-hole clearance with adequate ground plane spacing."),
        InspectionFinding(aspect="Power Decoupling", status="Notice", observation="C2 (10nF) is placed close to Pin 5 as recommended by Texas Instruments datasheet; consider adding a bulk 100µF bypass cap directly across VCC and GND pins for noisy supplies."),
    ]

    result = CircuitAnalysisResult(
        circuit_title="NE555 Astable Multivibrator Pulse Generator Board",
        circuit_type="Printed Circuit Board (PCB)",
        estimated_purpose="Configured as an astable multivibrator producing continuous digital square-wave pulses at approximately 6.5 Hz with a ~52% duty cycle, visually indicated by LED D1.",
        primary_power_domain="5V to 12V DC via terminal block J1",
        components=components,
        bill_of_materials=bom,
        inspection_notes=inspection,
        circuit_highlights=[
            "Classic 555 astable timer topology with charging through R1+R2 and discharging through R2",
            "Calculated oscillation frequency: f ≈ 1.44 / ((R1 + 2*R2) * C1) ≈ 6.85 Hz (period ~146 ms)",
            "Visual blinking diagnostic via D1 with 330Ω current limiting resistor",
            "Dedicated external tap (J2) for connecting external microcontroller or oscilloscope probe"
        ]
    )

    return img, result


def create_sample_2_arduino_board() -> Tuple[Image.Image, CircuitAnalysisResult]:
    """Generates an image and analysis result for a Microcontroller Development Board (Arduino / ESP style)."""
    width, height = 1000, 750
    # Deep blue solder mask PCB
    img = Image.new("RGB", (width, height), (12, 38, 82))
    draw = ImageDraw.Draw(img)
    font_bold = get_default_font(18)
    font_sm = get_default_font(12)
    font_title = get_default_font(24)

    # PCB Board outline
    draw.rectangle([(50, 50), (950, 700)], outline=(20, 60, 130), width=4)
    # Mounting holes
    for hx, hy in [(80, 80), (920, 80), (80, 670), (920, 670)]:
        draw.ellipse([(hx - 15, hy - 15), (hx + 15, hy + 15)], fill=(210, 190, 120), outline=(240, 220, 150), width=2)
        draw.ellipse([(hx - 9, hy - 9), (hx + 9, hy + 9)], fill=(8, 25, 55))

    # Header pin rows (top and bottom)
    for px in range(120, 890, 48):
        # Top pin header J1
        draw.rectangle([(px - 8, 90), (px + 8, 120)], fill=(218, 165, 32), outline=(160, 120, 20), width=2)
        # Bottom pin header J2
        draw.rectangle([(px - 8, 630), (px + 8, 660)], fill=(218, 165, 32), outline=(160, 120, 20), width=2)

    draw.text((120, 65), "D13 D12 D11 D10 D9  D8  D7  D6  D5  D4  D3  D2  GND RST RX  TX", fill=(240, 240, 240), font=font_sm)
    draw.text((120, 675), "VIN GND RST 5V  A7  A6  A5  A4  A3  A2  A1  A0  REF 3V3 D1  D0", fill=(240, 240, 240), font=font_sm)

    # Silkscreen board name
    draw.text((320, 160), "AVR-CORE NANO DEVELOPMENT BOARD", fill=(245, 245, 245), font=font_title)
    draw.text((400, 190), "OPEN SOURCE HARDWARE V3.0", fill=(180, 200, 230), font=font_sm)

    # 1. Main MCU: ATmega328P (U1) - QFP-32 surface mount package rotated 45 deg or square
    u1_box = (400, 260, 600, 460)
    draw.rectangle([(390, 250), (610, 470)], outline=(240, 240, 240), width=2)
    draw.rectangle(u1_box, fill=(25, 26, 28), outline=(60, 65, 75), width=2)
    # Pins around QFP chip
    for i in range(420, 580, 20):
        draw.rectangle([(i - 4, 245), (i + 4, 260)], fill=(190, 195, 200)) # Top pins
        draw.rectangle([(i - 4, 460), (i + 4, 475)], fill=(190, 195, 200)) # Bottom pins
        draw.rectangle([(385, i - 4), (400, i + 4)], fill=(190, 195, 200)) # Left pins
        draw.rectangle([(600, i - 4), (615, i + 4)], fill=(190, 195, 200)) # Right pins

    draw.ellipse([(415, 275), (425, 285)], fill=(160, 160, 160)) # Pin 1 index dot
    draw.text((425, 335), "ATMEGA328P", fill=(225, 225, 230), font=font_bold)
    draw.text((455, 365), "-AU  2348", fill=(160, 165, 175), font=font_sm)
    draw.text((490, 225), "U1", fill=(240, 240, 240), font=font_bold)

    # 2. Crystal Oscillator Y1 (16.000 MHz)
    # Metallic HC-49SMD can
    draw.rectangle([(650, 330), (750, 390)], fill=(190, 195, 205), outline=(130, 135, 145), width=2)
    draw.text((660, 350), "16.000 MHz", fill=(40, 45, 55), font=font_sm)
    draw.text((680, 305), "Y1", fill=(240, 240, 240), font=font_bold)

    # 3. LDO Voltage Regulator U2 (AMS1117-5.0)
    # SOT-223 package with tab
    draw.rectangle([(230, 270), (330, 350)], fill=(30, 32, 35), outline=(70, 75, 80), width=2)
    draw.rectangle([(250, 255), (310, 270)], fill=(190, 195, 205)) # Tab
    # 3 bottom pins
    draw.rectangle([(245, 350), (265, 365)], fill=(190, 195, 205))
    draw.rectangle([(270, 350), (290, 365)], fill=(190, 195, 205))
    draw.rectangle([(295, 350), (315, 365)], fill=(190, 195, 205))
    draw.text((240, 300), "AMS1117", fill=(210, 215, 220), font=font_sm)
    draw.text((255, 320), "5.0V", fill=(170, 175, 180), font=font_sm)
    draw.text((265, 230), "U2", fill=(240, 240, 240), font=font_bold)

    # 4. USB Type-C Connector J3
    draw.rectangle([(70, 330), (160, 430)], fill=(195, 200, 210), outline=(140, 145, 155), width=3)
    draw.rectangle([(85, 355), (145, 405)], fill=(40, 42, 48))
    draw.text((80, 305), "J3 (USB-C)", fill=(240, 240, 240), font=font_bold)

    # 5. USB-UART Bridge IC U3 (CH340C)
    draw.rectangle([(220, 420), (340, 520)], fill=(30, 32, 35), outline=(70, 75, 80), width=2)
    draw.text((235, 460), "CH340C", fill=(210, 215, 220), font=font_bold)
    draw.text((265, 395), "U3", fill=(240, 240, 240), font=font_bold)

    # 6. Reset Switch SW1
    draw.rectangle([(700, 450), (770, 520)], fill=(180, 185, 190), outline=(110, 115, 120), width=2)
    draw.ellipse([(718, 468), (752, 502)], fill=(210, 50, 40), outline=(150, 30, 20), width=2) # Red button
    draw.text((705, 425), "SW1 (RST)", fill=(240, 240, 240), font=font_bold)

    # 7. SMD Capacitors C1, C2
    draw.rectangle([(240, 210), (270, 230)], fill=(200, 170, 120), outline=(150, 120, 80))
    draw.rectangle([(290, 210), (320, 230)], fill=(200, 170, 120), outline=(150, 120, 80))
    draw.text((260, 185), "C1/C2 (10µF)", fill=(240, 240, 240), font=font_sm)

    # 8. Status LEDs (PWR, D13, TX, RX)
    led_coords = [
        (430, 505, "PWR", (50, 220, 70)),
        (470, 505, "L13", (230, 180, 30)),
        (510, 505, "TX",  (50, 150, 240)),
        (550, 505, "RX",  (50, 150, 240)),
    ]
    for lx, ly, label, col in led_coords:
        draw.rectangle([(lx, ly), (lx + 20, ly + 25)], fill=col, outline=(255, 255, 255), width=1)
        draw.text((lx - 2, ly + 30), label, fill=(240, 240, 240), font=font_sm)

    components = [
        CircuitComponent(
            id="U1",
            name="Microchip ATmega328P 8-Bit AVR Microcontroller",
            category="Integrated Circuit",
            designator="U1",
            value_or_rating="32KB Flash, 20MHz, 5V",
            package="TQFP-32 Surface Mount",
            markings="ATMEGA328P-AU 2348",
            location_description="Center of development board",
            bounding_box=BoundingBox(
                ymin=int((245 / height) * 1000),
                xmin=int((385 / width) * 1000),
                ymax=int((475 / height) * 1000),
                xmax=int((615 / width) * 1000)
            ),
            estimated_function="Primary embedded computing system controller executing user firmware and GPIO logic",
            confidence="High"
        ),
        CircuitComponent(
            id="Y1",
            name="Quartz Crystal Resonator",
            category="Crystal / Oscillator",
            designator="Y1",
            value_or_rating="16.000 MHz (±20ppm)",
            package="HC-49/SMD Metal Can",
            markings="16.000 MHz",
            location_description="Right of microcontroller U1",
            bounding_box=BoundingBox(
                ymin=int((325 / height) * 1000),
                xmin=int((645 / width) * 1000),
                ymax=int((395 / height) * 1000),
                xmax=int((755 / width) * 1000)
            ),
            estimated_function="Generates accurate 16 MHz master clock reference for ATmega328P MCU",
            confidence="High"
        ),
        CircuitComponent(
            id="U2",
            name="AMS1117-5.0 Low-Dropout Linear Voltage Regulator",
            category="Integrated Circuit",
            designator="U2",
            value_or_rating="5.0V Output, 1A Max",
            package="SOT-223",
            markings="AMS1117 5.0V",
            location_description="Left side near USB input",
            bounding_box=BoundingBox(
                ymin=int((250 / height) * 1000),
                xmin=int((225 / width) * 1000),
                ymax=int((365 / height) * 1000),
                xmax=int((335 / width) * 1000)
            ),
            estimated_function="Steps down VIN (7V-12V) down to clean regulated 5.0V system power rail",
            confidence="High"
        ),
        CircuitComponent(
            id="U3",
            name="WCH CH340C USB to UART Serial Bridge",
            category="Integrated Circuit",
            designator="U3",
            value_or_rating="Full-speed USB 2.0 to UART",
            package="SOP-16",
            markings="CH340C",
            location_description="Lower left, adjacent to USB port",
            bounding_box=BoundingBox(
                ymin=int((415 / height) * 1000),
                xmin=int((215 / width) * 1000),
                ymax=int((525 / height) * 1000),
                xmax=int((345 / width) * 1000)
            ),
            estimated_function="Translates PC USB communications to serial UART for bootloader flashing and telemetry",
            confidence="High"
        ),
        CircuitComponent(
            id="J3",
            name="USB Type-C Receptacle",
            category="Connector / Terminal",
            designator="J3",
            value_or_rating="USB 2.0 Type-C Female",
            package="SMD 16-Pin Type-C",
            markings="J3",
            location_description="Left board edge",
            bounding_box=BoundingBox(
                ymin=int((325 / height) * 1000),
                xmin=int((65 / width) * 1000),
                ymax=int((435 / height) * 1000),
                xmax=int((165 / width) * 1000)
            ),
            estimated_function="Provides 5V VBUS power and bidirectional communication data link to host computer",
            confidence="High"
        ),
        CircuitComponent(
            id="SW1",
            name="Micro Tactile Pushbutton Switch",
            category="Switch / Button",
            designator="SW1",
            value_or_rating="12V 50mA Momentary",
            package="SMD 4-Pad Tact Switch",
            markings="RST",
            location_description="Right middle area",
            bounding_box=BoundingBox(
                ymin=int((445 / height) * 1000),
                xmin=int((695 / width) * 1000),
                ymax=int((525 / height) * 1000),
                xmax=int((775 / width) * 1000)
            ),
            estimated_function="Hardware reset button pulling MCU RESET pin active-low",
            confidence="High"
        ),
        CircuitComponent(
            id="LED_ARRAY",
            name="Status Surface-Mount LED Bank",
            category="Diode / LED",
            designator="LED1-LED4",
            value_or_rating="0805 SMD LEDs (PWR, D13, TX, RX)",
            package="SMD 0805",
            markings="PWR, L13, TX, RX",
            location_description="Below microcontroller U1",
            bounding_box=BoundingBox(
                ymin=int((500 / height) * 1000),
                xmin=int((420 / width) * 1000),
                ymax=int((545 / height) * 1000),
                xmax=int((580 / width) * 1000)
            ),
            estimated_function="Provides visual diagnostics: Power Good, Pin 13 user LED, Serial TX, and Serial RX",
            confidence="High"
        ),
    ]

    bom = [
        BOMItem(designator="U1", component_type="Microcontroller", description="ATmega328P-AU 8-bit AVR MCU", package="TQFP-32", quantity=1, notes="20MHz 32KB Flash"),
        BOMItem(designator="Y1", component_type="Crystal Oscillator", description="16.000 MHz Quartz Crystal", package="HC-49/SMD", quantity=1, notes="18pF load"),
        BOMItem(designator="U2", component_type="Voltage Regulator", description="AMS1117-5.0V LDO Regulator", package="SOT-223", quantity=1, notes="Max 1A"),
        BOMItem(designator="U3", component_type="Interface IC", description="CH340C USB-Serial Converter", package="SOP-16", quantity=1, notes="Built-in clock"),
        BOMItem(designator="J3", component_type="Connector", description="USB Type-C Female Port", package="SMD Type-C", quantity=1, notes="Power & Data"),
        BOMItem(designator="SW1", component_type="Switch", description="Momentary Tactile Pushbutton", package="SMD 4-Pad", quantity=1, notes="Active-low Reset"),
        BOMItem(designator="LED1-LED4", component_type="LED", description="0805 Surface Mount LEDs (Green, Yellow, Blue)", package="SMD 0805", quantity=4, notes="PWR, L, TX, RX"),
    ]

    inspection = [
        InspectionFinding(aspect="Surface Mount Soldering", status="Good", observation="TQFP-32 leads show uniform solder meniscus with no visible bridging or tombstoning."),
        InspectionFinding(aspect="Thermal Dissipation", status="Good", observation="AMS1117 regulator has exposed copper heat sink pad tied to GND plane for thermal relief."),
        InspectionFinding(aspect="Crystal Routing", status="Good", observation="16 MHz crystal Y1 placed in close proximity to XTAL1/XTAL2 pins with symmetric trace routing."),
    ]

    result = CircuitAnalysisResult(
        circuit_title="AVR Nano Microcontroller Development Board",
        circuit_type="Development Board / Module",
        estimated_purpose="General-purpose embedded microcontroller development and prototyping platform compatible with Arduino IDE, featuring built-in USB-to-UART flashing and onboard 5V regulation.",
        primary_power_domain="5V DC via USB-C (J3) or 7V-12V DC unregulated via VIN pin",
        components=components,
        bill_of_materials=bom,
        inspection_notes=inspection,
        circuit_highlights=[
            "Full-featured ATmega328P architecture with 32KB flash, 2KB SRAM, 1KB EEPROM",
            "Modern USB Type-C interface connected via WCH CH340C USB bridge",
            "Onboard 5.0V LDO regulator supporting wide external supply voltages",
            "Standard dual 15-pin 2.54mm breadboard-friendly pin headers for rapid prototyping"
        ]
    )

    return img, result


def create_sample_3_buck_converter() -> Tuple[Image.Image, CircuitAnalysisResult]:
    """Generates an image and analysis result for an LM2596 DC-DC Step-Down Buck Converter Module."""
    width, height = 1000, 750
    # Industrial blue PCB
    img = Image.new("RGB", (width, height), (15, 45, 95))
    draw = ImageDraw.Draw(img)
    font_bold = get_default_font(18)
    font_sm = get_default_font(12)
    font_title = get_default_font(24)

    # PCB Board outline
    draw.rectangle([(40, 40), (960, 710)], outline=(30, 80, 160), width=4)
    # Heavy copper ground planes
    draw.rectangle([(180, 180), (820, 560)], outline=(40, 95, 180), width=2)

    draw.text((280, 70), "LM2596 DC-DC STEP-DOWN BUCK MODULE", fill=(245, 245, 245), font=font_title)
    draw.text((360, 105), "HIGH EFFICIENCY SWITCHING REGULATOR", fill=(190, 215, 245), font=font_sm)

    # 1. Main Switching IC: LM2596 (U1) - TO-263 / D2PAK with large copper heatsink tab
    draw.rectangle([(400, 220), (580, 380)], fill=(28, 30, 34), outline=(65, 70, 80), width=3)
    draw.rectangle([(420, 195), (560, 220)], fill=(190, 195, 205)) # Heavy metal tab
    # 5 Thick pins
    for px in [425, 455, 490, 525, 555]:
        draw.rectangle([(px - 6, 380), (px + 6, 405)], fill=(190, 195, 205))
    draw.text((430, 280), "LM2596S", fill=(225, 225, 230), font=font_bold)
    draw.text((445, 310), "-ADJ  P+", fill=(160, 165, 175), font=font_sm)
    draw.text((475, 165), "U1", fill=(240, 240, 240), font=font_bold)

    # 2. High-Current Power Inductor L1 (47µH shielded toroidal / SMD drum)
    # Toroid coil or shielded SMD
    draw.rectangle([(620, 240), (820, 440)], fill=(40, 42, 46), outline=(90, 95, 105), width=3)
    draw.ellipse([(645, 265), (795, 415)], fill=(32, 34, 38), outline=(130, 110, 70), width=6) # Copper wire windings
    draw.text((695, 330), "470", fill=(210, 215, 220), font=font_bold)
    draw.text((680, 355), "(47µH)", fill=(170, 175, 185), font=font_sm)
    draw.text((700, 205), "L1 (47µH)", fill=(240, 240, 240), font=font_bold)

    # 3. Input Electrolytic Capacitor C_IN (220µF 35V)
    draw.rectangle([(100, 220), (240, 360)], outline=(240, 240, 240), width=2)
    draw.ellipse([(110, 230), (230, 350)], fill=(35, 40, 45), outline=(15, 18, 20), width=3) # Black body
    draw.pieslice([(110, 230), (230, 350)], start=135, end=225, fill=(210, 215, 225)) # Neg stripe
    draw.text((112, 285), "---", fill=(20, 20, 20), font=font_bold)
    draw.text((150, 275), "220µF", fill=(255, 255, 255), font=font_bold)
    draw.text((160, 300), "35V", fill=(220, 220, 220), font=font_sm)
    draw.text((140, 190), "C_IN", fill=(240, 240, 240), font=font_bold)

    # 4. Output Electrolytic Capacitor C_OUT (470µF 25V)
    draw.rectangle([(780, 480), (920, 620)], outline=(240, 240, 240), width=2)
    draw.ellipse([(790, 490), (910, 610)], fill=(35, 40, 45), outline=(15, 18, 20), width=3)
    draw.pieslice([(790, 490), (910, 610)], start=135, end=225, fill=(210, 215, 225))
    draw.text((792, 545), "---", fill=(20, 20, 20), font=font_bold)
    draw.text((830, 535), "470µF", fill=(255, 255, 255), font=font_bold)
    draw.text((840, 560), "25V", fill=(220, 220, 220), font=font_sm)
    draw.text((820, 450), "C_OUT", fill=(240, 240, 240), font=font_bold)

    # 5. Schottky Catch Diode D1 (SS34 / 1N5822) - SMC package
    draw.rectangle([(440, 440), (540, 510)], fill=(30, 32, 35), outline=(70, 75, 80), width=2)
    draw.rectangle([(445, 440), (460, 510)], fill=(220, 225, 230)) # Cathode band
    draw.text((475, 465), "SS34", fill=(220, 225, 230), font=font_bold)
    draw.text((475, 520), "D1 (SS34)", fill=(240, 240, 240), font=font_bold)

    # 6. Precision Trimming Potentiometer RV1 (Bourns 3296 blue trimpot)
    draw.rectangle([(250, 430), (370, 550)], fill=(0, 102, 204), outline=(0, 70, 150), width=3) # Distinctive blue box
    draw.ellipse([(330, 450), (355, 475)], fill=(218, 165, 32), outline=(150, 110, 20), width=2) # Brass adjust screw
    draw.line([(335, 462), (350, 462)], fill=(30, 30, 30), width=2)
    draw.text((265, 485), "W103 (10k)", fill=(255, 255, 255), font=font_sm)
    draw.text((275, 395), "RV1 (TRIMPOT)", fill=(240, 240, 240), font=font_bold)

    # 7. Screw Terminal Connections: IN+, IN-, OUT+, OUT-
    terminals = [
        (80, 480, "IN+", "IN-", "DC INPUT (3-40V)"),
        (650, 560, "OUT+", "OUT-", "REGULATED OUT (1.5-35V)"),
    ]
    for tx, ty, lab1, lab2, group in terminals:
        draw.rectangle([(tx, ty), (tx + 90, ty + 120)], fill=(35, 120, 55), outline=(20, 75, 35), width=2)
        draw.ellipse([(tx + 15, ty + 20), (tx + 40, ty + 45)], fill=(180, 185, 190), outline=(100, 105, 110), width=2)
        draw.ellipse([(tx + 15, ty + 75), (tx + 40, ty + 100)], fill=(180, 185, 190), outline=(100, 105, 110), width=2)
        draw.text((tx + 50, ty + 25), lab1, fill=(240, 240, 240), font=font_bold)
        draw.text((tx + 50, ty + 80), lab2, fill=(240, 240, 240), font=font_bold)
        draw.text((tx - 10, ty - 25), group, fill=(200, 220, 250), font=font_sm)

    components = [
        CircuitComponent(
            id="U1",
            name="Texas Instruments LM2596S-ADJ Step-Down Switching Regulator",
            category="Integrated Circuit",
            designator="U1",
            value_or_rating="3A Adjustable Step-Down, 150kHz",
            package="TO-263-5 (D2PAK)",
            markings="LM2596S -ADJ P+",
            location_description="Center of PCB heatsink zone",
            bounding_box=BoundingBox(
                ymin=int((195 / height) * 1000),
                xmin=int((400 / width) * 1000),
                ymax=int((405 / height) * 1000),
                xmax=int((580 / width) * 1000)
            ),
            estimated_function="Core monolithic step-down switching regulator operating at 150 kHz PWM frequency with 3A continuous load capability",
            confidence="High"
        ),
        CircuitComponent(
            id="L1",
            name="Shielded Power Inductor",
            category="Inductor / Transformer",
            designator="L1",
            value_or_rating="47µH, 3A Rated",
            package="Surface Mount Shielded Drum Inductor",
            markings="470 (47µH)",
            location_description="Upper right quadrant",
            bounding_box=BoundingBox(
                ymin=int((235 / height) * 1000),
                xmin=int((615 / width) * 1000),
                ymax=int((445 / height) * 1000),
                xmax=int((825 / width) * 1000)
            ),
            estimated_function="Energy storage inductor smoothing discontinuous pulsed current into continuous output DC",
            confidence="High"
        ),
        CircuitComponent(
            id="C_IN",
            name="Radial Aluminum Electrolytic Capacitor",
            category="Capacitor",
            designator="C_IN",
            value_or_rating="220µF 35V Low ESR",
            package="Radial Can Through-Hole (8mm)",
            markings="220µF 35V with negative polarity band",
            location_description="Input power side (left)",
            bounding_box=BoundingBox(
                ymin=int((215 / height) * 1000),
                xmin=int((95 / width) * 1000),
                ymax=int((365 / height) * 1000),
                xmax=int((245 / width) * 1000)
            ),
            estimated_function="Input reservoir capacitor filtering input voltage ripple and handling switching currents",
            confidence="High"
        ),
        CircuitComponent(
            id="C_OUT",
            name="Radial Aluminum Electrolytic Capacitor",
            category="Capacitor",
            designator="C_OUT",
            value_or_rating="470µF 25V Low ESR",
            package="Radial Can Through-Hole (10mm)",
            markings="470µF 25V with negative polarity band",
            location_description="Output power side (bottom right)",
            bounding_box=BoundingBox(
                ymin=int((475 / height) * 1000),
                xmin=int((775 / width) * 1000),
                ymax=int((625 / height) * 1000),
                xmax=int((925 / width) * 1000)
            ),
            estimated_function="Output filter capacitor stabilizing DC rail and suppressing 150kHz switching ripple",
            confidence="High"
        ),
        CircuitComponent(
            id="D1",
            name="Schottky Barrier Power Rectifier Diode",
            category="Diode / LED",
            designator="D1",
            value_or_rating="SS34 (40V 3A Schottky)",
            package="DO-214AB (SMC)",
            markings="SS34 with white cathode bar",
            location_description="Directly beneath U1 switching pin",
            bounding_box=BoundingBox(
                ymin=int((435 / height) * 1000),
                xmin=int((435 / width) * 1000),
                ymax=int((515 / height) * 1000),
                xmax=int((545 / width) * 1000)
            ),
            estimated_function="Freewheeling / catch diode maintaining inductor current recirculation during switch OFF intervals",
            confidence="High"
        ),
        CircuitComponent(
            id="RV1",
            name="Multi-Turn Cermet Trimming Potentiometer",
            category="Potentiometer",
            designator="RV1",
            value_or_rating="10kΩ Bourns 3296 Style",
            package="Through-Hole 3296 Cermet Trimpot",
            markings="W103 (10k)",
            location_description="Center-left blue block",
            bounding_box=BoundingBox(
                ymin=int((425 / height) * 1000),
                xmin=int((245 / width) * 1000),
                ymax=int((555 / height) * 1000),
                xmax=int((375 / width) * 1000)
            ),
            estimated_function="Forms adjustable resistive voltage divider feeding back to Pin 4 (Feedback) to set target output voltage",
            confidence="High"
        ),
    ]

    bom = [
        BOMItem(designator="U1", component_type="Switching Regulator", description="LM2596S-ADJ 3A Step-Down Regulator", package="TO-263-5", quantity=1, notes="150kHz PWM"),
        BOMItem(designator="L1", component_type="Power Inductor", description="47µH 3A High-Current Inductor", package="SMD Shielded", quantity=1, notes="Low DCR"),
        BOMItem(designator="C_IN", component_type="Electrolytic Capacitor", description="220µF 35V Low-ESR Radial", package="Radial 8mm", quantity=1, notes="Input Filter"),
        BOMItem(designator="C_OUT", component_type="Electrolytic Capacitor", description="470µF 25V Low-ESR Radial", package="Radial 10mm", quantity=1, notes="Output Filter"),
        BOMItem(designator="D1", component_type="Schottky Diode", description="SS34 40V 3A Schottky Rectifier", package="DO-214AB (SMC)", quantity=1, notes="Catch Diode"),
        BOMItem(designator="RV1", component_type="Potentiometer", description="10kΩ Multi-turn Cermet Trimpot", package="Bourns 3296", quantity=1, notes="Voltage Trimmer"),
    ]

    inspection = [
        InspectionFinding(aspect="Thermal Management", status="Good", observation="Large copper pour beneath LM2596 heatsink tab facilitates thermal dissipation at high currents."),
        InspectionFinding(aspect="Loop Area Minimization", status="Good", observation="Critical high-di/dt switching loop (LM2596 switch, D1 diode, and C_IN ground) is routed with minimal trace length."),
        InspectionFinding(aspect="Capacitor Polarity", status="Good", observation="Negative stripe on both C_IN and C_OUT electrolytic capacitors matches silkscreen orientation."),
    ]

    result = CircuitAnalysisResult(
        circuit_title="LM2596 DC-DC Step-Down Buck Converter Module",
        circuit_type="Printed Circuit Board (PCB)",
        estimated_purpose="High-efficiency switch-mode DC-DC buck converter designed to step down higher DC voltages (4V-40V) to an adjustable lower voltage (1.23V-35V) with up to 3A output current.",
        primary_power_domain="Input: 4.5V - 40V DC; Output: 1.23V - 35V DC adjustable",
        components=components,
        bill_of_materials=bom,
        inspection_notes=inspection,
        circuit_highlights=[
            "Monolithic buck switching converter based on LM2596 with integrated 3A power switch",
            "Wide conversion efficiency range (typically 80% to 92%)",
            "Multi-turn precision trimpot RV1 allows micro-fine voltage adjustments",
            "Freewheeling SS34 Schottky diode provides ultra-fast recovery time and minimal forward drop"
        ]
    )

    return img, result


def save_samples(directory: str = "samples") -> Dict[str, CircuitAnalysisResult]:
    """Generates all sample circuit images and writes them to the specified directory."""
    os.makedirs(directory, exist_ok=True)
    results = {}

    samples = [
        ("ne555_timer_pcb.png", create_sample_1_ne555_pcb),
        ("arduino_nano_board.png", create_sample_2_arduino_board),
        ("lm2596_buck_converter.png", create_sample_3_buck_converter),
    ]

    for filename, generator in samples:
        filepath = os.path.join(directory, filename)
        img, result = generator()
        img.save(filepath, format="PNG")
        results[filepath] = result

    return results

