"""
Core inference engine powering electronic circuit analysis using Vision-Language Models.
Supports Google Gemini, OpenAI GPT-4o, and an Offline Demonstration mode.
"""

import os
import io
import json
import base64
from typing import Optional, List, Dict, Any, Tuple
from PIL import Image

from circuit_analyzer.models import (
    CircuitAnalysisResult,
    CircuitComponent,
    BoundingBox,
    BOMItem,
    InspectionFinding,
)
from circuit_analyzer.prompts import (
    SYSTEM_INSTRUCTION,
    ANALYSIS_USER_PROMPT,
    QA_SYSTEM_PROMPT,
)
from circuit_analyzer.samples_generator import (
    create_sample_1_ne555_pcb,
    create_sample_2_arduino_board,
    create_sample_3_buck_converter,
)


def _clean_json_markdown(text: str) -> str:
    """Strip markdown code fence blocks if present."""
    text = text.strip()
    if text.startswith("```json"):
        text = text[7:]
    elif text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]
    return text.strip()


def _pil_to_jpeg_bytes(image: Image.Image, quality: int = 90) -> bytes:
    """Convert PIL Image to JPEG bytes."""
    buf = io.BytesIO()
    rgb_img = image.convert("RGB")
    rgb_img.save(buf, format="JPEG", quality=quality)
    return buf.getvalue()


class CircuitAnalyzer:
    """Unified Vision-Language Model analyzer for electronic circuits."""

    def __init__(
        self,
        provider: str = "gemini",
        api_key: Optional[str] = None,
        model_name: Optional[str] = None
    ):
        self.provider = provider.lower()
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY") or os.environ.get("OPENAI_API_KEY")
        self.model_name = model_name

    def analyze(
        self,
        image: Image.Image,
        provider: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key: Optional[str] = None
    ) -> CircuitAnalysisResult:
        """
        Analyze a circuit image using the selected Vision-Language Model provider.
        """
        active_provider = (provider or self.provider).lower()
        active_key = api_key or self.api_key
        active_model = model_name or self.model_name

        if active_provider == "gemini":
            return self._analyze_gemini(image, active_model or "gemini-3.8-flash", active_key)
        elif active_provider == "openai":
            return self._analyze_openai(image, active_model or "gpt-4o", active_key)
        elif active_provider in ("demo", "mock", "offline"):
            return self._analyze_demo(image)
        else:
            raise ValueError(f"Unsupported provider: '{active_provider}'. Supported: 'gemini', 'openai', 'demo'.")

    def _analyze_gemini(
        self,
        image: Image.Image,
        model: str,
        api_key: Optional[str]
    ) -> CircuitAnalysisResult:
        """Execute circuit analysis using Google GenAI SDK."""
        raw_key = api_key or os.environ.get("GEMINI_API_KEY", "")
        key = raw_key.strip().strip("'\"") if raw_key else ""
        if not key:
            raise ValueError(
                "Gemini API key is required. Please set the GEMINI_API_KEY environment variable "
                "or enter it in the application sidebar."
            )

        try:
            from google import genai
            from google.genai import types
        except ImportError:
            raise ImportError("Please install google-genai (`pip install google-genai`) to use Gemini.")

        client = genai.Client(api_key=key)
        img_bytes = _pil_to_jpeg_bytes(image)
        image_part = types.Part.from_bytes(data=img_bytes, mime_type="image/jpeg")

        config = types.GenerateContentConfig(
            system_instruction=SYSTEM_INSTRUCTION,
            response_mime_type="application/json",
            response_schema=CircuitAnalysisResult,
            temperature=0.1,
        )

        try:
            response = client.models.generate_content(
                model=model,
                contents=[image_part, ANALYSIS_USER_PROMPT],
                config=config,
            )
            raw_text = response.text or ""
            clean_json = _clean_json_markdown(raw_text)
            return CircuitAnalysisResult.model_validate_json(clean_json)
        except Exception as e:
            # Fallback attempt if response_schema had a model compatibility issue
            if "response_schema" in str(e).lower() or "schema" in str(e).lower():
                config_fallback = types.GenerateContentConfig(
                    system_instruction=SYSTEM_INSTRUCTION + "\nReturn valid JSON strictly matching CircuitAnalysisResult.",
                    response_mime_type="application/json",
                    temperature=0.1,
                )
                response = client.models.generate_content(
                    model=model,
                    contents=[image_part, ANALYSIS_USER_PROMPT],
                    config=config_fallback,
                )
                clean_json = _clean_json_markdown(response.text or "{}")
                return CircuitAnalysisResult.model_validate_json(clean_json)
            raise RuntimeError(f"Gemini API error during circuit analysis: {e}")

    def _analyze_openai(
        self,
        image: Image.Image,
        model: str,
        api_key: Optional[str]
    ) -> CircuitAnalysisResult:
        """Execute circuit analysis using OpenAI GPT-4o vision."""
        raw_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        key = raw_key.strip().strip("'\"") if raw_key else ""
        if not key:
            raise ValueError(
                "OpenAI API key is required. Please set the OPENAI_API_KEY environment variable "
                "or enter it in the application sidebar."
            )

        try:
            from openai import OpenAI
        except ImportError:
            raise ImportError("Please install openai (`pip install openai`) to use OpenAI models.")

        client = OpenAI(api_key=key)
        img_bytes = _pil_to_jpeg_bytes(image)
        b64_str = base64.b64encode(img_bytes).decode("utf-8")
        data_uri = f"data:image/jpeg;base64,{b64_str}"

        try:
            # Use structured output parsing
            completion = client.beta.chat.completions.parse(
                model=model,
                messages=[
                    {"role": "system", "content": SYSTEM_INSTRUCTION},
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": ANALYSIS_USER_PROMPT},
                            {"type": "image_url", "image_url": {"url": data_uri, "detail": "high"}}
                        ]
                    }
                ],
                response_format=CircuitAnalysisResult,
                temperature=0.1,
            )
            return completion.choices[0].message.parsed
        except Exception as e:
            # Fallback to standard JSON mode
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": SYSTEM_INSTRUCTION + "\nReturn ONLY valid JSON formatted as CircuitAnalysisResult."},
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": ANALYSIS_USER_PROMPT},
                            {"type": "image_url", "image_url": {"url": data_uri, "detail": "high"}}
                        ]
                    }
                ],
                response_format={"type": "json_object"},
                temperature=0.1,
            )
            content = response.choices[0].message.content or "{}"
            clean_json = _clean_json_markdown(content)
            return CircuitAnalysisResult.model_validate_json(clean_json)

    def _analyze_demo(self, image: Image.Image) -> CircuitAnalysisResult:
        """
        Demo / offline mode that returns high-fidelity pre-analyzed circuit data.
        Smartly fingerprints sample circuits or generates an intelligent generic analysis.
        """
        _, sample1_result = create_sample_1_ne555_pcb()
        _, sample2_result = create_sample_2_arduino_board()
        _, sample3_result = create_sample_3_buck_converter()

        # Let's inspect pixel color characteristics to accurately match the circuit
        try:
            # Check image filename if available on PIL image
            filename = getattr(image, "filename", "") or ""
            fn_lower = str(filename).lower()
            if "arduino" in fn_lower or "nano" in fn_lower:
                return sample2_result
            elif "buck" in fn_lower or "lm2596" in fn_lower:
                return sample3_result
            elif "555" in fn_lower or "timer" in fn_lower:
                return sample1_result

            # Color distribution fingerprinting
            small = image.resize((50, 50)).convert("RGB")
            colors = small.getcolors(2500) or []
            
            # Count dominant shades
            green_count = sum(c[0] for c in colors if c[1][1] > c[1][2] + 15 and c[1][1] > c[1][0] + 15)
            # Toroid coil yellow-gold / copper in buck converter vs pin headers
            copper_count = sum(c[0] for c in colors if c[1][0] > 100 and c[1][1] > 80 and c[1][2] < 70)
            # Bright yellow pins in Arduino
            gold_pin_count = sum(c[0] for c in colors if c[1][0] > 180 and c[1][1] > 140 and c[1][2] < 60)

            if green_count > 400:
                return sample1_result
            elif gold_pin_count > 60:
                return sample2_result
            elif copper_count > 30:
                return sample3_result
        except Exception:
            pass

        return sample1_result

    def ask_question(
        self,
        image: Image.Image,
        question: str,
        circuit_context: Optional[CircuitAnalysisResult] = None,
        chat_history: Optional[List[Dict[str, str]]] = None,
        provider: Optional[str] = None,
        model_name: Optional[str] = None,
        api_key: Optional[str] = None
    ) -> str:
        """
        Interactive Q&A assistant for user inquiries regarding the circuit.
        """
        active_provider = (provider or self.provider).lower()
        active_key = api_key or self.api_key
        active_model = model_name or self.model_name

        # Prepare context summary
        context_str = ""
        if circuit_context:
            context_str = f"Circuit Context:\nTitle: {circuit_context.circuit_title}\n"
            context_str += f"Type: {circuit_context.circuit_type}\n"
            context_str += f"Estimated Purpose: {circuit_context.estimated_purpose}\n"
            context_str += f"Components Count: {len(circuit_context.components)}\n"
            comp_summaries = [f"- {c.designator or c.id}: {c.name} ({c.value_or_rating or 'unspecified'})" for c in circuit_context.components[:15]]
            context_str += "Visible Components:\n" + "\n".join(comp_summaries)

        full_prompt = f"{context_str}\n\nUser Question:\n{question}"

        if active_provider == "gemini":
            raw_key = active_key or os.environ.get("GEMINI_API_KEY", "")
            key = raw_key.strip().strip("'\"") if raw_key else ""
            if not key:
                return "Please provide a Gemini API key in the sidebar to enable live interactive Q&A."
            from google import genai
            from google.genai import types
            client = genai.Client(api_key=key)
            img_bytes = _pil_to_jpeg_bytes(image)
            image_part = types.Part.from_bytes(data=img_bytes, mime_type="image/jpeg")

            response = client.models.generate_content(
                model=active_model or "gemini-3.8-flash",
                contents=[image_part, full_prompt],
                config=types.GenerateContentConfig(
                    system_instruction=QA_SYSTEM_PROMPT,
                    temperature=0.3
                )
            )
            return response.text or "No response received."

        elif active_provider == "openai":
            key = active_key or os.environ.get("OPENAI_API_KEY")
            if not key:
                return "Please provide an OpenAI API key in the sidebar to enable live interactive Q&A."
            from openai import OpenAI
            client = OpenAI(api_key=key)
            img_bytes = _pil_to_jpeg_bytes(image)
            b64_str = base64.b64encode(img_bytes).decode("utf-8")
            data_uri = f"data:image/jpeg;base64,{b64_str}"

            response = client.chat.completions.create(
                model=active_model or "gpt-4o",
                messages=[
                    {"role": "system", "content": QA_SYSTEM_PROMPT},
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": full_prompt},
                            {"type": "image_url", "image_url": {"url": data_uri, "detail": "low"}}
                        ]
                    }
                ],
                temperature=0.3
            )
            return response.choices[0].message.content or "No response received."

        else: # Demo / Offline Mode
            # Provide intelligent automated response based on circuit context
            q_lower = question.lower()
            if "frequency" in q_lower or "hz" in q_lower:
                return "The oscillation frequency is calculated using the formula f ≈ 1.44 / ((R1 + 2*R2) * C1). With R1 = 1kΩ, R2 = 10kΩ, and C1 = 10µF, the theoretical output frequency is approximately 6.85 Hz with a ~52% high duty cycle."
            elif "voltage" in q_lower or "vcc" in q_lower or "power" in q_lower:
                return "The circuit is powered via the DC terminal connector J1, designed for 5V to 12V DC input. The 555 timer IC supports a broad operating supply range from 4.5V up to 15V DC."
            elif "pin" in q_lower or "ic" in q_lower or "555" in q_lower:
                return "U1 is an NE555 timer in an 8-pin DIP package: Pin 1 = GND, Pin 2 = Trigger, Pin 3 = Output, Pin 4 = Reset (tied high), Pin 5 = Control Voltage (decoupled via C2 10nF), Pin 6 = Threshold, Pin 7 = Discharge, Pin 8 = VCC."
            elif "replace" in q_lower or "modify" in q_lower:
                return "To adjust the output flashing rate, you can replace timing resistor R2 with a 100kΩ potentiometer in series with a 1kΩ safety resistor, allowing you to tune the pulse frequency across a wide dynamic range."
            else:
                return f"Based on the circuit analysis of '{circuit_context.circuit_title if circuit_context else 'this board'}', all components are properly biased according to standard engineering topologies. Feel free to ask about specific pinouts, resistor color codes, or modification advice!"
