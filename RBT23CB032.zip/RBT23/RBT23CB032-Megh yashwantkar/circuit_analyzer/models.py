"""
Data models and schemas for Electronic Circuit Component Analysis.
"""

from typing import List, Optional, Literal
from pydantic import BaseModel, Field


class BoundingBox(BaseModel):
    """Normalized bounding box coordinates.
    Accepts coordinates either in 0-1000 scale (standard Gemini box_2d) or 0.0-1.0 scale.
    """
    ymin: float = Field(..., description="Top coordinate (0-1000 or 0.0-1.0)")
    xmin: float = Field(..., description="Left coordinate (0-1000 or 0.0-1.0)")
    ymax: float = Field(..., description="Bottom coordinate (0-1000 or 0.0-1.0)")
    xmax: float = Field(..., description="Right coordinate (0-1000 or 0.0-1.0)")

    def to_pixel_box(self, width: int, height: int) -> tuple[int, int, int, int]:
        """Convert normalized coordinates to absolute pixel values (left, top, right, bottom)."""
        scale_y = 1000.0 if (self.ymin > 1.0 or self.ymax > 1.0) else 1.0
        scale_x = 1000.0 if (self.xmin > 1.0 or self.xmax > 1.0) else 1.0

        left = int(max(0, min(width, (self.xmin / scale_x) * width)))
        top = int(max(0, min(height, (self.ymin / scale_y) * height)))
        right = int(max(0, min(width, (self.xmax / scale_x) * width)))
        bottom = int(max(0, min(height, (self.ymax / scale_y) * height)))

        # Ensure valid rectangle
        if right <= left:
            right = min(width, left + 10)
        if bottom <= top:
            bottom = min(height, top + 10)

        return (left, top, right, bottom)


class CircuitComponent(BaseModel):
    """Detailed representation of a visible electronic component."""
    id: str = Field(..., description="Unique identifier (e.g., 'C1', 'R1', 'U1', 'COMP_01')")
    name: str = Field(..., description="Common component name (e.g. 'NE555 Precision Timer', 'Electrolytic Capacitor')")
    category: Literal[
        "Integrated Circuit",
        "Resistor",
        "Capacitor",
        "Diode / LED",
        "Transistor / MOSFET",
        "Inductor / Transformer",
        "Connector / Terminal",
        "Switch / Button",
        "Crystal / Oscillator",
        "Sensor / Module",
        "Potentiometer",
        "Protection Device",
        "Test Point / Marking",
        "Other"
    ] = Field(..., description="Classification category of the component")
    designator: Optional[str] = Field(None, description="PCB silkscreen reference designator if visible (e.g. 'R1', 'C3', 'U2')")
    value_or_rating: Optional[str] = Field(None, description="Identified value, rating or part number (e.g. '10kΩ', '100µF 16V', 'AMS1117-3.3')")
    package: Optional[str] = Field(None, description="Package or footprint type (e.g. 'DIP-8', 'SMD 0805', 'TO-220', 'Radial Through-Hole')")
    markings: Optional[str] = Field(None, description="Visible text, numbers, color bands or codes (e.g. 'Brown-Black-Orange-Gold', '103', 'TI NE555P')")
    location_description: Optional[str] = Field(None, description="Spatial location (e.g., 'Center of PCB', 'Near top power rail', 'Adjacent to U1')")
    bounding_box: Optional[BoundingBox] = Field(None, description="Normalized bounding box coordinates of the component")
    estimated_function: Optional[str] = Field(None, description="Inferred role in circuit (e.g. 'Decoupling capacitor for MCU', 'Timing resistor', 'Input filter')")
    confidence: Literal["High", "Medium", "Low", "Estimated"] = Field("Medium", description="Identification confidence level")


class BOMItem(BaseModel):
    """Bill of Materials entry."""
    designator: str = Field(..., description="Reference designators (e.g. 'R1, R2' or 'U1')")
    component_type: str = Field(..., description="Category or generic type")
    description: str = Field(..., description="Component description and specifications")
    package: str = Field("Unknown", description="Package or mounting style")
    quantity: int = Field(1, description="Quantity counted")
    notes: Optional[str] = Field(None, description="Additional notes or specifications")


class InspectionFinding(BaseModel):
    """Observations regarding circuit quality, assembly, or potential issues."""
    aspect: str = Field(..., description="Area of observation (e.g., 'Solder Quality', 'Polarity', 'Thermal Dissipation', 'Silkscreen Readability')")
    status: Literal["Good", "Notice", "Warning"] = Field("Notice", description="Assessment level")
    observation: str = Field(..., description="Detailed observation or potential risk")


class CircuitAnalysisResult(BaseModel):
    """Complete structured circuit analysis response from the Vision-Language Model."""
    circuit_title: str = Field(..., description="Concise descriptive title of the circuit")
    circuit_type: Literal[
        "Printed Circuit Board (PCB)",
        "Breadboard Prototyping Circuit",
        "Schematic Diagram",
        "Development Board / Module",
        "Perforated Board (Perfboard)",
        "Mixed / Other"
    ] = Field(..., description="Form factor of the analyzed circuit image")
    estimated_purpose: str = Field(..., description="Comprehensive explanation of what the circuit does and its intended application")
    primary_power_domain: Optional[str] = Field(None, description="Estimated voltage supply or power characteristics (e.g. '5V DC via USB', '12V regulated', '3.3V battery')")
    components: List[CircuitComponent] = Field(default_factory=list, description="List of all visible electronic components detected")
    bill_of_materials: List[BOMItem] = Field(default_factory=list, description="Consolidated Bill of Materials")
    inspection_notes: List[InspectionFinding] = Field(default_factory=list, description="Assembly, soldering, and design inspection notes")
    circuit_highlights: List[str] = Field(default_factory=list, description="Key functional or architectural highlights")
