"""
Visualization utilities for circuit component annotations and image inspection.
"""

from typing import List, Optional, Tuple, Dict
from PIL import Image, ImageDraw, ImageFont
import io

from circuit_analyzer.models import CircuitComponent, CircuitAnalysisResult

# Distinct color palette mapped to electronic component categories
CATEGORY_COLORS: Dict[str, Tuple[int, int, int]] = {
    "Integrated Circuit": (229, 57, 53),     # Vivid Crimson
    "Resistor": (2, 136, 209),                # Deep Blue
    "Capacitor": (251, 140, 0),               # Vibrant Amber
    "Diode / LED": (67, 160, 71),             # Emerald Green
    "Transistor / MOSFET": (142, 36, 170),    # Violet
    "Inductor / Transformer": (141, 110, 99), # Copper Brown
    "Connector / Terminal": (84, 110, 122),   # Slate Blue
    "Switch / Button": (0, 137, 123),         # Teal
    "Crystal / Oscillator": (30, 136, 229),   # Electric Blue
    "Sensor / Module": (233, 30, 99),         # Pink/Magenta
    "Potentiometer": (245, 124, 0),           # Dark Orange
    "Protection Device": (198, 40, 40),       # Dark Red
    "Test Point / Marking": (120, 144, 156),  # Muted Blue-Grey
    "Other": (117, 117, 117)                  # Medium Grey
}

DEFAULT_COLOR = (120, 144, 156)


def get_category_color(category: str) -> Tuple[int, int, int]:
    """Return the RGB color assigned to a category."""
    return CATEGORY_COLORS.get(category, DEFAULT_COLOR)


def get_default_font(size: int = 14) -> ImageFont.ImageFont:
    """Load default truetype or fallback bitmap font."""
    font_names = [
        "arial.ttf", "segoeui.ttf", "calibri.ttf", "DejaVuSans.ttf", "Helvetica.ttf"
    ]
    for font_name in font_names:
        try:
            return ImageFont.truetype(font_name, size)
        except Exception:
            continue
    return ImageFont.load_default()


def annotate_circuit_image(
    image: Image.Image,
    components: List[CircuitComponent],
    selected_categories: Optional[List[str]] = None,
    highlight_component_id: Optional[str] = None,
    show_labels: bool = True,
    box_thickness: int = 3,
    alpha_fill: int = 40
) -> Image.Image:
    """
    Draw labeled bounding boxes over the circuit image with color-coded categories.
    
    Args:
        image: PIL Image of the circuit
        components: List of CircuitComponent with bounding_box
        selected_categories: Optional list of categories to include (all if None)
        highlight_component_id: If provided, will make this component visually prominent
        show_labels: Whether to render component label badges
        box_thickness: Width of the outline stroke
        alpha_fill: Transparency for box fill (0 = transparent, 255 = solid)
    """
    img_copy = image.convert("RGBA")
    width, height = img_copy.size

    # Create an overlay for semi-transparent bounding box fills
    overlay = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    overlay_draw = ImageDraw.Draw(overlay)
    
    # Base draw for crisp borders and text
    draw = ImageDraw.Draw(img_copy)
    font = get_default_font(max(12, int(height * 0.018)))

    for comp in components:
        if not comp.bounding_box:
            continue

        if selected_categories is not None and comp.category not in selected_categories:
            continue

        left, top, right, bottom = comp.bounding_box.to_pixel_box(width, height)
        color = get_category_color(comp.category)
        is_highlighted = (highlight_component_id is not None and comp.id == highlight_component_id)

        current_thickness = box_thickness + 2 if is_highlighted else box_thickness
        fill_alpha = 100 if is_highlighted else alpha_fill

        # Semi-transparent rectangle fill
        overlay_draw.rectangle(
            [(left, top), (right, bottom)],
            fill=(*color, fill_alpha)
        )

        # Crisp outline
        draw.rectangle(
            [(left, top), (right, bottom)],
            outline=(*color, 255),
            width=current_thickness
        )

        # Label pill
        if show_labels:
            tag = comp.designator or comp.id
            desc = comp.value_or_rating or comp.name
            # Keep label concise
            short_desc = desc if len(desc) <= 16 else (desc[:14] + "..")
            label_text = f"{tag}: {short_desc}"

            # Calculate text size using font bbox
            bbox = font.getbbox(label_text)
            text_w = bbox[2] - bbox[0]
            text_h = bbox[3] - bbox[1]

            pill_pad = 4
            pill_left = left
            pill_top = max(0, top - text_h - pill_pad * 2 - 2)
            pill_right = min(width, left + text_w + pill_pad * 2)
            pill_bottom = pill_top + text_h + pill_pad * 2

            # Background pill for readability
            draw.rectangle(
                [(pill_left, pill_top), (pill_right, pill_bottom)],
                fill=(*color, 240)
            )
            # Label text in white
            draw.text(
                (pill_left + pill_pad, pill_top + pill_pad - bbox[1]),
                label_text,
                fill=(255, 255, 255, 255),
                font=font
            )

    # Composite the overlay onto the image
    annotated = Image.alpha_composite(img_copy, overlay)
    return annotated.convert("RGB")


def crop_component(
    image: Image.Image,
    component: CircuitComponent,
    padding_pct: float = 0.15
) -> Optional[Image.Image]:
    """
    Crop an individual component from the circuit image with optional contextual padding.
    """
    if not component.bounding_box:
        return None

    width, height = image.size
    left, top, right, bottom = component.bounding_box.to_pixel_box(width, height)

    box_w = right - left
    box_h = bottom - top

    pad_x = int(box_w * padding_pct)
    pad_y = int(box_h * padding_pct)

    crop_left = max(0, left - pad_x)
    crop_top = max(0, top - pad_y)
    crop_right = min(width, right + pad_x)
    crop_bottom = min(height, bottom + pad_y)

    return image.crop((crop_left, crop_top, crop_right, crop_bottom))

