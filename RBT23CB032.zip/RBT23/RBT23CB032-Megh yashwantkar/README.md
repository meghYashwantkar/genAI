# ⚡ Electronic Circuit Component Vision Analyzer

An AI-powered computer vision and hardware intelligence application that accepts images of electronic circuits (PCBs, breadboards, schematics, and breakout modules) and generates a comprehensive, structured description of all visible components using state-of-the-art **Vision-Language Models (VLMs)**.

Powered by **Google Gemini** (Gemini 3.8 Flash / 2.5 Flash / 2.0 Flash) and **OpenAI GPT-4o**, along with a built-in zero-configuration **Demo / Offline Mode**.

---

## 🌟 Key Features

- **🔍 Automatic Component Detection & Localization:**
  - Pinpoints reference designators (`R1`, `C3`, `U1`, `D2`, `J1`, etc.).
  - Extracts part numbers (e.g., `NE555`, `ATmega328P`, `AMS1117-5.0`, `LM2596S`).
  - Decodes resistor color bands and SMD 3/4-digit / EIA-96 codes (`103` → 10kΩ).
  - Identifies capacitor chemistries (electrolytics with polarity stripes, ceramic discs, SMD ceramics).
  - Classifies package footprints (`DIP-8`, `TQFP-32`, `SOT-223`, `TO-263`, `0805 SMD`, `Through-Hole`).
  - Computes spatial bounding box coordinates `[ymin, xmin, ymax, xmax]`.

- **🎨 Color-Coded Circuit Annotator & Component Magnifier:**
  - Highlights components with category-specific color palettes (Integrated Circuits in Crimson, Resistors in Blue, Capacitors in Amber, Diodes in Green, Inductors in Copper, etc.).
  - High-resolution **Component Magnifier Tool** to crop and zoom into any single component for silkscreen and solder joint inspection.

- **📊 Consolidated Bill of Materials (BOM) Generator:**
  - Aggregates detected parts by designator, category, description, and package footprint.
  - One-click export to **CSV** (compatible with Mouser, DigiKey, and Excel).

- **⚡ Circuit Architecture & Functional Analysis:**
  - Infers circuit topology (e.g., Astable Multivibrator, Buck Switching Regulator, MCU Development Board).
  - Summarizes operating power domains, voltage rails, and signal paths.

- **🛠️ Automated PCB Quality & Assembly Inspection:**
  - Verifies capacitor and diode polarities against silkscreen markings.
  - Checks IC pin 1 index notches and orientation.
  - Reviews thermal dissipation pours and high-frequency loop layout.

- **💬 Interactive Circuit Q&A Assistant:**
  - Ask follow-up engineering questions about the uploaded circuit (pinouts, component substitution, formulas, diagnostic steps).

- **💻 Multi-Interface (Web App + CLI):**
  - Rich interactive **Streamlit web application** (`app.py`).
  - Scriptable **Command Line Interface** (`cli.py`).
  - Python SDK library (`circuit_analyzer`).

---

## 📁 Project Architecture

```
practical_genai/
├── app.py                     # Interactive Streamlit Web Application
├── cli.py                     # Command-line interface with export capabilities
├── requirements.txt           # Python dependencies
├── .env.example               # Template for API keys
├── README.md                  # System documentation
├── circuit_analyzer/          # Core Python Package
│   ├── __init__.py            # Public package API
│   ├── models.py              # Pydantic schemas (Component, BoundingBox, BOM, AnalysisResult)
│   ├── prompts.py             # Domain-specific engineering prompts and instructions
│   ├── engine.py              # Unified VLM inference engine (Gemini, OpenAI, Demo Mode)
│   ├── visualizer.py          # Bounding box rendering & component cropping engine
│   ├── exporter.py            # CSV BOM, Markdown report, and JSON data serializers
│   └── samples_generator.py   # High-resolution synthetic circuit generator
├── samples/                   # Preloaded circuit boards for testing
│   ├── ne555_timer_pcb.png
│   ├── lm2596_buck_converter.png
│   └── arduino_nano_board.png
└── tests/
    └── test_analyzer.py       # Automated unit test suite
```

---

## 🚀 Quickstart

### 1. Installation

Ensure you have Python 3.10+ installed:

```bash
git clone <repo-url>
cd practical_genai
pip install -r requirements.txt
```

### 2. Configure API Keys (Optional)

You can set your API key as an environment variable or type it directly into the Streamlit sidebar:

```bash
# For Google Gemini (Recommended)
set GEMINI_API_KEY="your-google-api-key"

# For OpenAI GPT-4o
set OPENAI_API_KEY="your-openai-api-key"
```

> **Note:** If you do not have an API key right now, you can select **Demo / Offline Mode** to immediately explore the full application with pre-analyzed circuit samples!

---

## 🖥️ Running the Streamlit Web Application

Launch the modern web UI in your browser:

```bash
streamlit run app.py
```

### Features in the Web App:
1. **Model Selector:** Choose between Google Gemini (Gemini 3.8 Flash / 2.5 Flash / 2.0 Flash), OpenAI (GPT-4o), or Demo Mode.
2. **Input Gallery:** Pick one of the built-in circuit boards or upload any image (PNG, JPG, WEBP).
3. **Run Analysis:** Click **"Run Full Circuit Analysis"** to execute perception and recognition.
4. **Tabs Available:**
   - 🔍 **Visual Annotations & Magnifier:** Inspect bounding boxes and crop individual components.
   - 📋 **Visible Components:** Categorized component cards with value, package, and functional role.
   - 📊 **Bill of Materials (BOM):** Searchable table with CSV download.
   - ⚡ **Architecture & Theory:** Functional purpose and power domain overview.
   - 🛠️ **PCB Quality Inspection:** Solder, polarity, and thermal health checks.
   - 💬 **Interactive Q&A:** Chat with the AI about specific pins, modifications, or formulas.

---

## 💻 Running via Command Line Interface (CLI)

The CLI tool allows batch analysis and automated report generation:

```bash
# Analyze a sample board in Demo mode and save annotated image + BOM CSV
python cli.py --image samples/ne555_timer_pcb.png --provider demo --save-annotated ne555_annotated.png --export-bom bom.csv

# Analyze using Google Gemini with your API key
python cli.py --image my_pcb.jpg --provider gemini --model gemini-3.8-flash --export-markdown report.md

# Generate all sample circuit diagrams
python cli.py --generate-samples
```

### CLI Arguments:
- `--image`, `-i`: Path to the circuit image file.
- `--provider`, `-p`: Model provider (`gemini`, `openai`, `demo`).
- `--model`, `-m`: Specific model name (e.g. `gemini-2.5-flash`, `gpt-4o`).
- `--api-key`, `-k`: Explicit API key.
- `--save-annotated`: Output file path for the bounding-box annotated image.
- `--export-bom`: Output file path for CSV Bill of Materials.
- `--export-markdown`: Output file path for full Markdown engineering report.
- `--export-json`: Output file path for raw structured JSON output.

---

## 🏷️ Supported Component Taxonomy

The model recognizes and classifies parts into the following categories:

| Category | Typical Designator | Example Parts Identified |
|---|---|---|
| **Integrated Circuit** | `U`, `IC` | Microcontrollers (ATmega328P, ESP32), Timers (NE555), Regulators (AMS1117, LM2596), Op-Amps (LM358) |
| **Resistor** | `R` | Axial carbon film (color-band decoded), SMD chips (`0805`, `1206`, `0603`) |
| **Capacitor** | `C` | Radial aluminum electrolytics (with polarity check), Ceramic discs (`104`, `103`), Tantalum |
| **Diode / LED** | `D`, `LED` | Rectifiers (1N4007, SS34), Zeners, 5mm T-1 3/4 LEDs, 0805 SMD LEDs |
| **Transistor / MOSFET** | `Q` | NPN/PNP bipolar transistors (2N2222), N-channel MOSFETs (IRFZ44N), SOT-23 FETs |
| **Inductor / Transformer** | `L`, `T` | Toroidal power inductors, SMD drum inductors, RF chokes |
| **Connector / Terminal** | `J`, `P`, `CN` | Screw terminal blocks, USB Type-C / Micro-B, pin headers (2.54mm) |
| **Switch / Button** | `SW`, `PB` | Tactile pushbuttons, slide switches, DIP switches |
| **Crystal / Oscillator** | `Y`, `XTAL` | Quartz crystals (16.000 MHz, 32.768 kHz), Ceramic resonators |
| **Potentiometer** | `RV`, `VR` | Multi-turn cermet trimpots (Bourns 3296), Rotary potentiometers |

---

## 🧪 Running Unit Tests

Execute the automated test suite with Python's built-in `unittest`:

```bash
python -m unittest tests/test_analyzer.py
```

All 8 tests verify:
- Pydantic schema validation and JSON serialization.
- Bounding box coordinate transformations (0-1000 and 0.0-1.0 to pixel coordinates).
- Visualizer drawing and category color consistency.
- Component magnifier cropping accuracy.
- CSV BOM, Markdown, and JSON exporters.
- Demo engine inference and multi-turn circuit Q&A.

---

## 📄 License

MIT License. Developed for Practical Generative AI and Computer Vision Applications.

