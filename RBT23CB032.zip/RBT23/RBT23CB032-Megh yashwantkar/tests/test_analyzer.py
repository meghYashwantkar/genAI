"""
Unit test suite for the Electronic Circuit Component Analyzer.
"""

import os
import unittest
from PIL import Image

from circuit_analyzer.models import (
    BoundingBox,
    CircuitComponent,
    BOMItem,
    InspectionFinding,
    CircuitAnalysisResult
)
from circuit_analyzer.visualizer import (
    annotate_circuit_image,
    crop_component,
    get_category_color,
    CATEGORY_COLORS
)
from circuit_analyzer.exporter import (
    export_bom_to_csv,
    export_to_markdown,
    export_to_json
)
from circuit_analyzer.samples_generator import (
    create_sample_1_ne555_pcb,
    create_sample_2_arduino_board,
    create_sample_3_buck_converter,
    save_samples
)
from circuit_analyzer.engine import CircuitAnalyzer


class TestCircuitAnalyzer(unittest.TestCase):

    def setUp(self):
        self.img, self.result = create_sample_1_ne555_pcb()

    def test_models_validation(self):
        """Test Pydantic model serialization and schema constraints."""
        json_data = self.result.model_dump_json()
        restored = CircuitAnalysisResult.model_validate_json(json_data)
        self.assertEqual(restored.circuit_title, self.result.circuit_title)
        self.assertEqual(len(restored.components), len(self.result.components))
        self.assertGreater(len(restored.bill_of_materials), 0)

    def test_bounding_box_scaling(self):
        """Test bounding box coordinate conversion from 0-1000 and 0.0-1.0 to pixel coordinates."""
        # 0-1000 scale
        box_1000 = BoundingBox(ymin=100, xmin=200, ymax=400, xmax=600)
        pixel_box = box_1000.to_pixel_box(width=1000, height=500)
        self.assertEqual(pixel_box, (200, 50, 600, 200))

        # 0.0-1.0 scale
        box_norm = BoundingBox(ymin=0.1, xmin=0.2, ymax=0.4, xmax=0.6)
        pixel_norm = box_norm.to_pixel_box(width=1000, height=500)
        self.assertEqual(pixel_norm, (200, 50, 600, 200))

    def test_category_colors(self):
        """Test color resolution for all component categories."""
        for cat in CATEGORY_COLORS:
            col = get_category_color(cat)
            self.assertEqual(len(col), 3)
            self.assertTrue(all(0 <= c <= 255 for c in col))

        # Unknown category fallback
        fallback = get_category_color("Superconductor")
        self.assertEqual(len(fallback), 3)

    def test_visualizer_annotation(self):
        """Test drawing bounding boxes on circuit images."""
        annotated = annotate_circuit_image(
            image=self.img,
            components=self.result.components,
            selected_categories=["Integrated Circuit", "Resistor"],
            show_labels=True,
            box_thickness=3
        )
        self.assertEqual(annotated.size, self.img.size)
        self.assertEqual(annotated.mode, "RGB")

    def test_component_cropping(self):
        """Test cropping an individual component out of the circuit."""
        u1 = next(c for c in self.result.components if c.designator == "U1")
        cropped = crop_component(self.img, u1, padding_pct=0.1)
        self.assertIsNotNone(cropped)
        self.assertGreater(cropped.width, 50)
        self.assertGreater(cropped.height, 50)

    def test_exports(self):
        """Test CSV BOM, Markdown, and JSON export utilities."""
        # CSV BOM
        csv_out = export_bom_to_csv(self.result)
        self.assertIn("Reference Designator", csv_out)
        self.assertIn("NE555P", csv_out)

        # Markdown report
        md_out = export_to_markdown(self.result)
        self.assertIn("# Circuit Analysis Report", md_out)
        self.assertIn("Bill of Materials", md_out)

        # JSON
        json_out = export_to_json(self.result)
        self.assertIn("NE555", json_out)

    def test_samples_generation(self):
        """Test generation of all sample circuits."""
        samples_dir = "test_samples_dir"
        created = save_samples(samples_dir)
        self.assertEqual(len(created), 3)
        for filepath in created:
            self.assertTrue(os.path.exists(filepath))
            # Clean up
            os.remove(filepath)
        if os.path.exists(samples_dir):
            os.rmdir(samples_dir)

    def test_demo_engine(self):
        """Test demo engine analysis and automated Q&A."""
        analyzer = CircuitAnalyzer(provider="demo")
        result = analyzer.analyze(self.img)
        self.assertIsNotNone(result.circuit_title)
        self.assertGreater(len(result.components), 0)

        # Test Q&A in demo mode
        answer = analyzer.ask_question(self.img, "What is the frequency of oscillation?", circuit_context=result)
        self.assertIn("Hz", answer)


if __name__ == "__main__":
    unittest.main()

