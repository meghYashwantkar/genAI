"""
Streamlit Web Application for Electronic Circuit Component Analysis using Vision-Language Models.
"""

import os
import io
from typing import Optional, List
import streamlit as st
from PIL import Image

from circuit_analyzer.models import CircuitAnalysisResult, CircuitComponent
from circuit_analyzer.engine import CircuitAnalyzer
from circuit_analyzer.visualizer import (
    annotate_circuit_image,
    crop_component,
    CATEGORY_COLORS,
    get_category_color,
)
from circuit_analyzer.exporter import (
    export_bom_to_csv,
    export_to_markdown,
    export_to_json,
)
from circuit_analyzer.samples_generator import save_samples


# Page Configuration
st.set_page_config(
    page_title="AI Circuit Inspector & Component Analyzer",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for modern styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.2rem;
        font-weight: 700;
        margin-bottom: 0.2rem;
        background: linear-gradient(90deg, #1E88E5, #00B0FF, #00E676);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    .sub-header {
        font-size: 1.05rem;
        color: #78909C;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background-color: rgba(30, 136, 229, 0.08);
        border: 1px solid rgba(30, 136, 229, 0.25);
        border-radius: 8px;
        padding: 12px 16px;
        margin-bottom: 10px;
    }
    .component-card {
        border-left: 4px solid #1E88E5;
        background-color: rgba(255, 255, 255, 0.03);
        border-radius: 4px 8px 8px 4px;
        padding: 12px 16px;
        margin-bottom: 12px;
    }
    .badge {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 0.75rem;
        font-weight: 600;
        margin-right: 6px;
    }
</style>
""", unsafe_allow_html=True)


def ensure_samples_exist() -> dict:
    """Ensure sample images are generated and return their paths."""
    samples_dir = "samples"
    os.makedirs(samples_dir, exist_ok=True)
    sample_files = {
        "NE555 Timer Astable Multivibrator Board": os.path.join(samples_dir, "ne555_timer_pcb.png"),
        "LM2596 Step-Down Buck Converter Module": os.path.join(samples_dir, "lm2596_buck_converter.png"),
        "AVR Nano Microcontroller Development Board": os.path.join(samples_dir, "arduino_nano_board.png"),
    }
    # Check if files exist; if not, generate them
    if not all(os.path.exists(p) for p in sample_files.values()):
        save_samples(samples_dir)
    return sample_files


# Initialize Session State
if "analysis_result" not in st.session_state:
    st.session_state.analysis_result = None
if "current_image" not in st.session_state:
    st.session_state.current_image = None
if "chat_messages" not in st.session_state:
    st.session_state.chat_messages = []
if "image_source_name" not in st.session_state:
    st.session_state.image_source_name = "None"


# Header
st.markdown('<div class="main-header">⚡ Electronic Circuit Component Vision Analyzer</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-header">Automated visual component recognition, Bill of Materials generation, PCB inspection & circuit intelligence using Vision-Language Models</div>', unsafe_allow_html=True)


# Sidebar Configuration
with st.sidebar:
    st.header("⚙️ Configuration")

    provider_choice = st.selectbox(
        "Vision-Language Model Provider",
        options=["Google Gemini", "OpenAI GPT-4", "Demo / Offline Mode"],
        index=0,
        help="Select the AI vision model provider to power component detection and analysis."
    )

    api_key = ""
    model_name = ""

    if provider_choice == "Google Gemini":
        provider_slug = "gemini"
        default_key = os.environ.get("GEMINI_API_KEY", "")
        raw_key = st.text_input(
            "Gemini API Key",
            value=default_key,
            type="password",
            help="Get your key at https://aistudio.google.com/app/apikey"
        )
        api_key = raw_key.strip().strip("'\"") if raw_key else ""
        model_name = st.selectbox(
            "Gemini Model",
            options=["gemini-3.8-flash", "gemini-3-flash", "gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-pro"],
            index=0
        )
        if not api_key:
            st.info("💡 You can try **Demo / Offline Mode** if you don't have an API key right now.")

    elif provider_choice == "OpenAI GPT-4":
        provider_slug = "openai"
        default_key = os.environ.get("OPENAI_API_KEY", "")
        raw_key = st.text_input(
            "OpenAI API Key",
            value=default_key,
            type="password",
            help="Get your key at https://platform.openai.com/api-keys"
        )
        api_key = raw_key.strip().strip("'\"") if raw_key else ""
        model_name = st.selectbox(
            "OpenAI Model",
            options=["gpt-4o", "gpt-4o-mini"],
            index=0
        )
    else:
        provider_slug = "demo"

    st.markdown("---")
    st.header("📷 Circuit Input")

    input_mode = st.radio(
        "Choose Image Source",
        options=["Select from Sample Gallery", "Upload Custom Image"],
        index=0
    )

    loaded_image = None
    loaded_name = ""

    sample_dict = ensure_samples_exist()

    if input_mode == "Select from Sample Gallery":
        sample_choice = st.selectbox("Preloaded Circuit Examples", list(sample_dict.keys()))
        sample_path = sample_dict[sample_choice]
        if os.path.exists(sample_path):
            loaded_image = Image.open(sample_path)
            loaded_name = sample_choice
    else:
        uploaded_file = st.file_uploader(
            "Upload Circuit Image (PCB, Breadboard, Schematic)",
            type=["png", "jpg", "jpeg", "webp"],
            help="Accepts high-resolution images of electronic circuits"
        )
        if uploaded_file is not None:
            loaded_image = Image.open(uploaded_file)
            loaded_name = uploaded_file.name

    if loaded_image is not None:
        if st.session_state.current_image is None or st.session_state.image_source_name != loaded_name:
            st.session_state.current_image = loaded_image
            st.session_state.image_source_name = loaded_name
            # Reset previous analysis if user switches to a different image
            st.session_state.analysis_result = None
            st.session_state.chat_messages = []

    st.markdown("---")
    st.header("🎨 Display Options")
    show_boxes = st.checkbox("Show Bounding Boxes", value=True)
    show_labels = st.checkbox("Show Component Badges", value=True)
    box_thickness = st.slider("Box Stroke Width", min_value=1, max_value=6, value=3)

    all_categories = list(CATEGORY_COLORS.keys())
    selected_categories = st.multiselect(
        "Filter by Categories",
        options=all_categories,
        default=all_categories
    )

    st.markdown("---")
    st.caption("Practical GenAI • Electronic Circuit VLM Analyzer")


# Main Display Logic
if st.session_state.current_image is None:
    st.info("👈 Please select a circuit sample or upload an image from the sidebar to get started.")
    st.stop()

# Layout: Image preview and run button
col_left, col_right = st.columns([1, 1], gap="medium")

with col_left:
    st.markdown(f"**Loaded Image:** `{st.session_state.image_source_name}` ({st.session_state.current_image.width} × {st.session_state.current_image.height} px)")
    st.image(st.session_state.current_image, use_container_width=True, caption="Source Circuit Image")

with col_right:
    st.markdown("### 🚀 Ready for VLM Analysis")
    st.write("Click below to trigger the Vision-Language Model. It will locate components, recognize markings, build a Bill of Materials, and diagnose PCB health.")

    analyze_clicked = st.button("🔍 Run Full Circuit Analysis", type="primary", use_container_width=True)

    if analyze_clicked:
        analyzer = CircuitAnalyzer(
            provider=provider_slug,
            api_key=api_key,
            model_name=model_name
        )

        with st.spinner(f"Analyzing circuit with {provider_choice} ({model_name or 'built-in'})..."):
            try:
                res = analyzer.analyze(
                    st.session_state.current_image,
                    provider=provider_slug,
                    model_name=model_name,
                    api_key=api_key
                )
                st.session_state.analysis_result = res
                st.session_state.chat_messages = []
                st.success("✅ Analysis completed successfully!")
            except Exception as e:
                st.error(f"Analysis error: {e}")
                if provider_slug in ("gemini", "openai"):
                    st.warning("Tip: Check that your API key is valid and has vision model permissions, or switch to 'Demo / Offline Mode' in the sidebar.")

    # Show Quick stats if analysis exists
    if st.session_state.analysis_result:
        res: CircuitAnalysisResult = st.session_state.analysis_result
        st.markdown(f"""
        <div class="metric-card">
            <h4 style="margin: 0 0 8px 0; color: #00B0FF;">{res.circuit_title}</h4>
            <p style="margin: 0; font-size: 0.9rem;"><b>Form Factor:</b> {res.circuit_type}</p>
            <p style="margin: 0; font-size: 0.9rem;"><b>Power Domain:</b> {res.primary_power_domain or 'Unspecified'}</p>
            <p style="margin: 0; font-size: 0.9rem;"><b>Components Detected:</b> {len(res.components)}</p>
        </div>
        """, unsafe_allow_html=True)


# Detailed Results Section
if st.session_state.analysis_result:
    res: CircuitAnalysisResult = st.session_state.analysis_result

    st.markdown("---")
    tabs = st.tabs([
        "🔍 Visual Annotations & Magnifier",
        "📋 Visible Components",
        "📊 Bill of Materials (BOM)",
        "⚡ Architecture & Theory",
        "🛠️ PCB Quality Inspection",
        "💬 Interactive Circuit Q&A"
    ])

    # Tab 1: Visual Annotations & Magnifier
    with tabs[0]:
        st.subheader("Visual Bounding Box Localization")

        # Generate annotated image
        annotated_img = annotate_circuit_image(
            st.session_state.current_image,
            res.components,
            selected_categories=selected_categories if show_boxes else [],
            show_labels=show_labels,
            box_thickness=box_thickness
        )

        col_img, col_tools = st.columns([3, 2], gap="medium")
        with col_img:
            st.image(annotated_img, use_container_width=True, caption="Annotated Circuit Layout")

        with col_tools:
            st.markdown("#### 🔬 Component Magnifier Tool")
            st.write("Inspect silkscreen text, solder joints, and footprints for any specific component:")

            comp_options = {
                f"[{c.designator or c.id}] {c.name} ({c.value_or_rating or c.category})": c
                for c in res.components
            }

            if comp_options:
                selected_label = st.selectbox("Select Component to Zoom In", list(comp_options.keys()))
                selected_comp = comp_options[selected_label]

                cropped = crop_component(st.session_state.current_image, selected_comp)
                if cropped:
                    st.image(cropped, width=280, caption=f"Magnified: {selected_comp.designator or selected_comp.id}")
                else:
                    st.info("No bounding box available for this component.")

                st.markdown(f"**Identified Part:** {selected_comp.name}")
                st.markdown(f"**Package / Footprint:** `{selected_comp.package or 'Unknown'}`")
                st.markdown(f"**Visible Markings:** `{selected_comp.markings or 'None'}`")
                st.markdown(f"**Role:** {selected_comp.estimated_function or 'N/A'}")

            st.markdown("---")
            st.markdown("#### Category Color Legend")
            legend_cols = st.columns(2)
            for idx, (cat_name, rgb) in enumerate(CATEGORY_COLORS.items()):
                target_col = legend_cols[idx % 2]
                hex_col = f"#{rgb[0]:02x}{rgb[1]:02x}{rgb[2]:02x}"
                target_col.markdown(
                    f'<span style="display:inline-block; width:12px; height:12px; background-color:{hex_col}; border-radius:3px; margin-right:6px;"></span>{cat_name}',
                    unsafe_allow_html=True
                )

    # Tab 2: Visible Components Breakdown
    with tabs[1]:
        st.subheader(f"Visible Components Inventory ({len(res.components)} items detected)")

        # Filter components by category
        filtered_comps = [c for c in res.components if c.category in selected_categories]

        if not filtered_comps:
            st.warning("No components match the current category filter selected in the sidebar.")
        else:
            grid_cols = st.columns(2)
            for i, comp in enumerate(filtered_comps):
                with grid_cols[i % 2]:
                    rgb = get_category_color(comp.category)
                    hex_color = f"#{rgb[0]:02x}{rgb[1]:02x}{rgb[2]:02x}"

                    st.markdown(f"""
                    <div class="component-card" style="border-left-color: {hex_color};">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <span style="font-size:1.1rem; font-weight:700;"><code>{comp.designator or comp.id}</code> — {comp.name}</span>
                            <span class="badge" style="background-color: {hex_color}22; color: {hex_color}; border: 1px solid {hex_color};">{comp.category}</span>
                        </div>
                        <p style="margin: 6px 0 2px 0;"><b>Value / Rating:</b> <code>{comp.value_or_rating or 'Unspecified'}</code></p>
                        <p style="margin: 2px 0;"><b>Package Footprint:</b> <code>{comp.package or 'Unknown'}</code></p>
                        <p style="margin: 2px 0;"><b>Markings / Text:</b> <i>{comp.markings or 'None'}</i></p>
                        <p style="margin: 2px 0;"><b>Location:</b> {comp.location_description or 'Unspecified'}</p>
                        <p style="margin: 6px 0 0 0; color: #B0BEC5; font-size: 0.9rem;"><b>Function:</b> {comp.estimated_function or 'N/A'}</p>
                    </div>
                    """, unsafe_allow_html=True)

    # Tab 3: Bill of Materials
    with tabs[2]:
        st.subheader("Consolidated Bill of Materials (BOM)")

        if res.bill_of_materials:
            bom_data = [
                {
                    "Designator": b.designator,
                    "Category": b.component_type,
                    "Description": b.description,
                    "Package": b.package,
                    "Quantity": b.quantity,
                    "Notes": b.notes or ""
                }
                for b in res.bill_of_materials
            ]
            st.dataframe(bom_data, use_container_width=True)
        else:
            st.info("No consolidated BOM items returned; see Components tab for individual list.")

        st.markdown("#### 📥 Export Options")
        exp_col1, exp_col2, exp_col3 = st.columns(3)

        with exp_col1:
            csv_str = export_bom_to_csv(res)
            st.download_button(
                label="📄 Download BOM as CSV",
                data=csv_str,
                file_name=f"{res.circuit_title.lower().replace(' ', '_')}_bom.csv",
                mime="text/csv",
                use_container_width=True
            )

        with exp_col2:
            md_str = export_to_markdown(res)
            st.download_button(
                label="📑 Download Engineering Report (Markdown)",
                data=md_str,
                file_name=f"{res.circuit_title.lower().replace(' ', '_')}_report.md",
                mime="text/markdown",
                use_container_width=True
            )

        with exp_col3:
            json_str = export_to_json(res)
            st.download_button(
                label="💾 Download Structured JSON",
                data=json_str,
                file_name=f"{res.circuit_title.lower().replace(' ', '_')}_data.json",
                mime="application/json",
                use_container_width=True
            )

    # Tab 4: Architecture & Theory
    with tabs[3]:
        st.subheader("Circuit Architecture & Functional Breakdown")
        st.markdown(f"### High-Level Purpose")
        st.write(res.estimated_purpose)

        st.markdown("### Power Domain")
        st.write(f"🔌 **Operating Supply:** `{res.primary_power_domain or 'Not explicitly identified'}`")

        if res.circuit_highlights:
            st.markdown("### Engineering Highlights")
            for highlight in res.circuit_highlights:
                st.markdown(f"- 💡 {highlight}")

    # Tab 5: PCB Quality Inspection
    with tabs[4]:
        st.subheader("Quality, Assembly & Design Observations")
        if res.inspection_notes:
            for item in res.inspection_notes:
                if item.status == "Good":
                    icon = "🟢"
                    badge_style = "background-color: rgba(67, 160, 71, 0.15); border-left: 4px solid #43A047;"
                elif item.status == "Warning":
                    icon = "🔴"
                    badge_style = "background-color: rgba(229, 57, 53, 0.15); border-left: 4px solid #E53935;"
                else:
                    icon = "🟡"
                    badge_style = "background-color: rgba(251, 140, 0, 0.15); border-left: 4px solid #FB8C00;"

                st.markdown(f"""
                <div style="padding: 12px; margin-bottom: 10px; border-radius: 4px; {badge_style}">
                    <h5 style="margin: 0 0 6px 0;">{icon} [{item.aspect}] — <i>{item.status}</i></h5>
                    <p style="margin: 0; font-size: 0.95rem;">{item.observation}</p>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.info("No specific quality flags or inspection notices detected.")

    # Tab 6: Interactive Circuit Q&A
    with tabs[5]:
        st.subheader("💬 Ask Questions About This Circuit")
        st.write("Converse with the Vision-Language Model to troubleshoot, calculate values, or explore modifications:")

        # Quick question pills
        q_cols = st.columns(3)
        sample_questions = [
            "What is the expected operating frequency?",
            "Explain the pinout and function of the primary IC.",
            "How can I adjust or modify this circuit?",
        ]

        preset_clicked = None
        for i, q_text in enumerate(sample_questions):
            with q_cols[i]:
                if st.button(f"💡 {q_text}", key=f"q_btn_{i}", use_container_width=True):
                    preset_clicked = q_text

        # Display conversation history
        for msg in st.session_state.chat_messages:
            with st.chat_message(msg["role"]):
                st.write(msg["content"])

        user_input = st.chat_input("Ask any question regarding this circuit (e.g. pinouts, values, signal paths)...")
        prompt_to_send = user_input or preset_clicked

        if prompt_to_send:
            # Add user message
            st.session_state.chat_messages.append({"role": "user", "content": prompt_to_send})
            with st.chat_message("user"):
                st.write(prompt_to_send)

            with st.chat_message("assistant"):
                with st.spinner("Analyzing circuit context..."):
                    analyzer = CircuitAnalyzer(
                        provider=provider_slug,
                        api_key=api_key,
                        model_name=model_name
                    )
                    reply = analyzer.ask_question(
                        image=st.session_state.current_image,
                        question=prompt_to_send,
                        circuit_context=res,
                        provider=provider_slug,
                        model_name=model_name,
                        api_key=api_key
                    )
                    st.write(reply)
                    st.session_state.chat_messages.append({"role": "assistant", "content": reply})

