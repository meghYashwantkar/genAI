"""
Command Line Interface (CLI) for Electronic Circuit Analyzer.
Usage:
    python cli.py --image samples/ne555_timer_pcb.png --provider demo --save-annotated annotated.png
    python cli.py --image my_circuit.jpg --provider gemini --export-bom bom.csv
"""

import argparse
import sys
import os

# Ensure UTF-8 output encoding in Windows console
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

from PIL import Image

from circuit_analyzer.engine import CircuitAnalyzer
from circuit_analyzer.visualizer import annotate_circuit_image
from circuit_analyzer.exporter import export_bom_to_csv, export_to_markdown, export_to_json
from circuit_analyzer.samples_generator import save_samples


def main():
    parser = argparse.ArgumentParser(
        description="Electronic Circuit Component Vision-Language Model Analyzer",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    parser.add_argument(
        "--image", "-i",
        type=str,
        help="Path to the circuit image file (PCB, schematic, breadboard, etc.)"
    )
    parser.add_argument(
        "--provider", "-p",
        type=str,
        default="gemini",
        choices=["gemini", "openai", "demo"],
        help="Vision-Language Model provider to use"
    )
    parser.add_argument(
        "--model", "-m",
        type=str,
        default=None,
        help="Model identifier (e.g., 'gemini-3.8-flash', 'gpt-4o')"
    )
    parser.add_argument(
        "--api-key", "-k",
        type=str,
        default=None,
        help="API Key (defaults to GEMINI_API_KEY or OPENAI_API_KEY env variables)"
    )
    parser.add_argument(
        "--save-annotated",
        type=str,
        default=None,
        help="Path to save the bounding-box annotated circuit image"
    )
    parser.add_argument(
        "--export-json",
        type=str,
        default=None,
        help="Path to save full analysis result as JSON"
    )
    parser.add_argument(
        "--export-bom",
        type=str,
        default=None,
        help="Path to export the Bill of Materials as CSV"
    )
    parser.add_argument(
        "--export-markdown",
        type=str,
        default=None,
        help="Path to export the comprehensive technical report as Markdown"
    )
    parser.add_argument(
        "--generate-samples",
        action="store_true",
        help="Generate built-in sample circuit images to the 'samples/' directory"
    )

    args = parser.parse_args()

    if args.generate_samples:
        print("[*] Generating sample circuit images in 'samples/' directory...")
        generated = save_samples("samples")
        for path in generated:
            print(f"  + Created: {path}")
        print("[+] Done generating samples.")
        if not args.image:
            return

    if not args.image:
        # Default to sample 1 if available or prompt user
        default_sample = os.path.join("samples", "ne555_timer_pcb.png")
        if os.path.exists(default_sample):
            print(f"[*] No image specified. Using default sample: {default_sample}")
            args.image = default_sample
        else:
            save_samples("samples")
            args.image = default_sample
            print(f"[*] Created and selected default sample: {default_sample}")

    if not os.path.exists(args.image):
        print(f"[-] Error: Image path '{args.image}' not found.", file=sys.stderr)
        sys.exit(1)

    print(f"[*] Loading circuit image: {args.image}")
    try:
        image = Image.open(args.image)
    except Exception as e:
        print(f"[-] Error opening image file: {e}", file=sys.stderr)
        sys.exit(1)

    # Automatically fall back to demo mode if provider is gemini/openai but no API key is set
    provider = args.provider
    if provider == "gemini" and not (args.api_key or os.environ.get("GEMINI_API_KEY")):
        print("[!] No GEMINI_API_KEY found in environment. Switching to high-fidelity 'demo' mode.")
        print("    (Set GEMINI_API_KEY to run live Gemini API calls).")
        provider = "demo"
    elif provider == "openai" and not (args.api_key or os.environ.get("OPENAI_API_KEY")):
        print("[!] No OPENAI_API_KEY found in environment. Switching to high-fidelity 'demo' mode.")
        print("    (Set OPENAI_API_KEY to run live OpenAI API calls).")
        provider = "demo"

    print(f"[*] Analyzing circuit using provider: {provider.upper()} (Model: {args.model or 'default'})...")
    analyzer = CircuitAnalyzer(provider=provider, api_key=args.api_key, model_name=args.model)

    try:
        result = analyzer.analyze(image, provider=provider, model_name=args.model, api_key=args.api_key)
    except Exception as e:
        print(f"[-] Analysis failed: {e}", file=sys.stderr)
        sys.exit(1)

    print("\n" + "=" * 70)
    print(f"CIRCUIT TITLE: {result.circuit_title}")
    print(f"CIRCUIT TYPE : {result.circuit_type}")
    print(f"POWER DOMAIN : {result.primary_power_domain or 'Unspecified'}")
    print("=" * 70)
    print(f"\n[+] Functional Purpose:\n{result.estimated_purpose}\n")

    print(f"[+] Detected Visible Components ({len(result.components)}):")
    print(f"{'Designator':<12} | {'Category':<22} | {'Value / Part #':<22} | {'Package':<18} | {'Confidence'}")
    print("-" * 88)
    for comp in result.components:
        des = comp.designator or comp.id
        cat = comp.category[:20]
        val = (comp.value_or_rating or comp.name)[:20]
        pkg = (comp.package or "Unknown")[:16]
        print(f"{des:<12} | {cat:<22} | {val:<22} | {pkg:<18} | {comp.confidence}")

    if result.bill_of_materials:
        print(f"\n[+] Bill of Materials ({len(result.bill_of_materials)} items):")
        print(f"{'Designator(s)':<15} | {'Category':<20} | {'Description':<28} | {'Qty':<4} | {'Package'}")
        print("-" * 85)
        for bom in result.bill_of_materials:
            print(f"{bom.designator:<15} | {bom.component_type:<20} | {bom.description[:26]:<28} | {bom.quantity:<4} | {bom.package}")

    if result.inspection_notes:
        print("\n[+] Quality & Assembly Inspection Notes:")
        for note in result.inspection_notes:
            print(f"  * [{note.aspect}] ({note.status}): {note.observation}")

    # Handle outputs
    if args.save_annotated:
        annotated_img = annotate_circuit_image(image, result.components)
        annotated_img.save(args.save_annotated)
        print(f"\n[+] Saved annotated image with bounding boxes to: {args.save_annotated}")

    if args.export_bom:
        csv_content = export_bom_to_csv(result)
        with open(args.export_bom, "w", encoding="utf-8") as f:
            f.write(csv_content)
        print(f"[+] Exported BOM to: {args.export_bom}")

    if args.export_markdown:
        md_content = export_to_markdown(result)
        with open(args.export_markdown, "w", encoding="utf-8") as f:
            f.write(md_content)
        print(f"[+] Exported Markdown report to: {args.export_markdown}")

    if args.export_json:
        json_content = export_to_json(result)
        with open(args.export_json, "w", encoding="utf-8") as f:
            f.write(json_content)
        print(f"[+] Exported JSON analysis to: {args.export_json}")

    print("\n[✓] Circuit Analysis completed successfully.")


if __name__ == "__main__":
    main()
